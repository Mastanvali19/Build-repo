package com.travelex.ctrip.ws.server;

import java.util.GregorianCalendar;

import javax.xml.datatype.DatatypeConfigurationException;
import javax.xml.datatype.DatatypeFactory;
import javax.xml.datatype.XMLGregorianCalendar;

import org.apache.log4j.Logger;

import com.ctrip.soa.financialservices.forex.forexvendorservice.types.v1.AckCodeType;
import com.ctrip.soa.financialservices.forex.forexvendorservice.types.v1.CurrencySyncInfoType;
import com.ctrip.soa.financialservices.forex.forexvendorservice.types.v1.RequestCommon;
import com.ctrip.soa.financialservices.forex.forexvendorservice.types.v1.ResponseCommon;
import com.ctrip.soa.financialservices.forex.forexvendorservice.types.v1.ResponseStatusType;
import com.ctrip.soa.financialservices.forex.forexvendorservice.v1.ForexVendorServiceInterface;
import com.ctrip.soa.financialservices.forex.forexvendorservice.v1.OrderStatusSyncRequest;
import com.ctrip.soa.financialservices.forex.forexvendorservice.v1.OrderStatusSyncResponse;
import com.ctrip.soa.financialservices.forex.forexvendorservice.v1.VendorCurrencyDataSyncRequest;
import com.ctrip.soa.financialservices.forex.forexvendorservice.v1.VendorCurrencyDataSyncResponse;

public class ForexVendorServiceImpl implements ForexVendorServiceInterface{

	private static final Logger logger = Logger.getLogger(ForexVendorServiceImpl.class);
	
	@Override
	public OrderStatusSyncResponse orderStatusSync(OrderStatusSyncRequest parameters) {
		//Logging Request Info
		logger.info("CTrip OrderID = " + parameters.getCtripOrderId() + " Order Status=" + parameters.getOrderStatus() + " VendorReferID=" + parameters.getVendorReferId() + " Common=" + logCommon(parameters.getRequestCommon()));
		
		//Creating Response
		OrderStatusSyncResponse response = new OrderStatusSyncResponse();
		response.setResponseCommon(buildResponseCommon());
		response.setResponseStatus(buildResponseStatus());
		
		return response;
	}

	
	@Override
	public VendorCurrencyDataSyncResponse vendorCurrencyDataSync(VendorCurrencyDataSyncRequest parameters) {
		//Logging Request Info
		logger.info("common=" + logCommon(parameters.getRequestCommon()));
		for(CurrencySyncInfoType c : parameters.getList()){
			logger.info("BranchCode=" + c.getBranchCode() + " VendorCode=" + c.getVendorCode() + " CurrencyCode=" + c.getCurrencyCode() + " BuyRate=" + c.getBuyRate() + " SellRate=" + c.getSellRate());
		}

		//Creating Response
		VendorCurrencyDataSyncResponse response = new VendorCurrencyDataSyncResponse();
		response.setResponseCommon(buildResponseCommon());
		response.setResponseStatus(buildResponseStatus());
		
		return response;
	}

	protected String logCommon(RequestCommon requestCommon){
		String common = "{";

		if(requestCommon != null){
			common +="ReqTime:" +requestCommon.getReqTime();
			common +=", TransID:" + requestCommon.getTransID();
			common +=", VendorCode:" + requestCommon.getVendorCode();
			common +=", VendorPassword:" + requestCommon.getVendorPassword();
		}
	
		common +="}";
		
		return common;
	}
	
	protected ResponseCommon buildResponseCommon(){
		ResponseCommon common = new ResponseCommon();

		common.setResCode("000000");
		common.setResDes("Description");
		common.setRspTime("123456789");
		common.setTransID("1");
		
		return common;
	}
	
	protected ResponseStatusType buildResponseStatus(){
		ResponseStatusType status = new ResponseStatusType();
		status.setAck(AckCodeType.SUCCESS);
		status.setBuild("build_1");
		status.setVersion("1.0.0");
		status.setTimestamp(getDate());		
		return status;
	}
	
	protected XMLGregorianCalendar getDate(){
		try {
			GregorianCalendar gcal = (GregorianCalendar) GregorianCalendar.getInstance();
			return DatatypeFactory.newInstance().newXMLGregorianCalendar(gcal);
		} catch (DatatypeConfigurationException e) {
			e.printStackTrace();
			return null;
		}
	}
	

	

	
}
