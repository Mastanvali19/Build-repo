package com.travelex.salt.ws.server;

import java.io.IOException;
import java.util.HashMap;
import java.util.Map;

import javax.security.auth.callback.Callback;
import javax.security.auth.callback.CallbackHandler;
import javax.security.auth.callback.UnsupportedCallbackException;

import org.apache.ws.security.WSPasswordCallback;

public class UTPasswordCallback implements CallbackHandler {
    
    private Map<String, String> passwords = new HashMap<String, String>();
    
    public UTPasswordCallback() {
        passwords.put("Alice", "ecilA");
        passwords.put("abcd", "dcba");
        passwords.put("clientx509v1", "storepassword");
        passwords.put("serverx509v1", "storepassword");
        passwords.put("s4ltn3eds4n4m3", "cr1ck3t");
    }

    public void handle(Callback[] callbacks) throws IOException, UnsupportedCallbackException {
        for (int i = 0; i < callbacks.length; i++) {
            WSPasswordCallback pc = (WSPasswordCallback)callbacks[i];

            String pass = passwords.get(pc.getIdentifier());
            if (pass != null) {
                pc.setPassword(pass);
                return;
            }
        }
    }
    
    public void setAliasPassword(String alias, String password) {
        passwords.put(alias, password);
    }

	public Map<String, String> getPasswords() {
		return passwords;
	}

	public void setPasswords(Map<String, String> passwords) {
		this.passwords = passwords;
	}

}
