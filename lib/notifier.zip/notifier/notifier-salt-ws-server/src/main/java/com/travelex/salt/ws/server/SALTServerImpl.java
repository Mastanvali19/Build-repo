package com.travelex.salt.ws.server;

import java.util.logging.Logger;

import javax.jws.WebMethod;
import javax.jws.WebParam;
import javax.jws.WebResult;
import javax.jws.WebService;
import javax.jws.soap.SOAPBinding;
import javax.xml.bind.annotation.XmlSeeAlso;

import saltservices.*;

@WebService(targetNamespace = "urn:SALTServices", name = "IOrder")
@XmlSeeAlso({ObjectFactory.class})
@SOAPBinding(parameterStyle = SOAPBinding.ParameterStyle.BARE)
public class SALTServerImpl implements IOrder{
	
    private static final Logger log = Logger.getLogger(SALTServerImpl.class.getPackage().getName());

    @WebResult(name = "OrderPostResponse", targetNamespace = "urn:SALTServices", partName = "parameters")
    @WebMethod(operationName = "Post", action = "urn:Order#Post")
    public OrderPostResponse post(
        @WebParam(partName = "parameters", name = "OrderPost", targetNamespace = "urn:SALTServices")
        OrderPost parameters
    ){
		log.info("<post> was invoked");
		return null;
	}

    @WebResult(name = "OrderUpdateResponse", targetNamespace = "urn:SALTServices", partName = "parameters")
    @WebMethod(operationName = "Update", action = "urn:Order#Update")
    public OrderUpdateResponse update(
        @WebParam(partName = "parameters", name = "OrderUpdate", targetNamespace = "urn:SALTServices")
        OrderUpdate parameters
    ){
		OrderUpdateResponse response = new OrderUpdateResponse();
		
		log.info("<update> was invoked");
		
		for(OrderUpdateItem item : parameters.getOrderUpdateItemList()){
			StringBuffer info = new StringBuffer();
			info.append("orderID<").append(item.getOrderID()).append(">");
			info.append("internalOrderID<").append(item.getOrderInternalID()).append(">");
			info.append("orderStatus<").append(item.getOrderStatus()).append(">");
			log.info(info.toString());
		}

		return response;
	}

}
