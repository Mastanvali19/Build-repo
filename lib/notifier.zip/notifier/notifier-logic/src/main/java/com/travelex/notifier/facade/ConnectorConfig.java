package com.travelex.notifier.facade;

import java.io.Serializable;

public class ConnectorConfig implements Serializable {

	private static final long serialVersionUID = 1L;
	private int id;
	private String connectorFactoryClassName;
	private String retries;
	private String intervals;
	private String email;

	public ConnectorConfig() {
	}

	public String getConnectorFactoryClassName() {
		return this.connectorFactoryClassName;
	}

	public int getId() {
		return this.id;
	}

	public void setConnectorFactoryClassName(String string) {
		this.connectorFactoryClassName = string;
	}

	public void setId(int i) {
		this.id = i;
	}

	public void setId(String i) {
		this.id = Integer.parseInt(i);
	}

	public String getRetries() {
		return retries;
	}

	public void setRetries(String retries) {
		this.retries = retries;
	}

	public String getIntervals() {
		return intervals;
	}

	public void setIntervals(String intervals) {
		this.intervals = intervals;
	}

	public String getEmail() {
		return email;
	}

	public void setEmail(String email) {
		this.email = email;
	}

	public String toString() {
		return getClass().getName() + "[" + "id=" + this.id + ", " + "retries="
				+ this.retries + ", " + "intervals=" + this.intervals + ", "
				+ "connectorFactoryClassName=" + this.connectorFactoryClassName
				+ "]";
	}

}
