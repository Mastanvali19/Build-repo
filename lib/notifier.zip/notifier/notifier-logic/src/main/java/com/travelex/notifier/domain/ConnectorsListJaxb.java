package com.travelex.notifier.domain;

import java.io.Serializable;
import java.util.ArrayList;

import javax.xml.bind.annotation.XmlElement;
import javax.xml.bind.annotation.XmlElementWrapper;
import javax.xml.bind.annotation.XmlRootElement;


@XmlRootElement(namespace = "com.travelex.notifier.domain")
public class ConnectorsListJaxb implements Serializable {

	private static final long serialVersionUID = 1L;
	@XmlElementWrapper(name = "connectorList")
	
	@XmlElement(name = "connector")
	private ArrayList<ConnectorJaxb> connectorList;
	
	public ArrayList<ConnectorJaxb> getConnectorsList() {
		return connectorList;
	}

	public void setConnectorList(ArrayList<ConnectorJaxb> connectorList) {
		this.connectorList = connectorList;
	}
}
