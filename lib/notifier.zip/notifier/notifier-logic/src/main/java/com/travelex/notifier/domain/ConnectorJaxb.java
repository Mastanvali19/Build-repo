package com.travelex.notifier.domain;

import java.io.Serializable;

import javax.xml.bind.annotation.XmlElement;
import javax.xml.bind.annotation.XmlRootElement;
import javax.xml.bind.annotation.XmlType;

@XmlRootElement(name = "connector")
@XmlType(propOrder = { "id", "retries", "intervals", "connectorFactoryClassName", "credential", "email" })
public class ConnectorJaxb implements Serializable {

	private static final long serialVersionUID = 1L;
	private String id;
	private String connectorFactoryClassName;
	private Integer retries;
	private String intervals;
	
	protected ConnectorCredentialJaxb credential;
	protected ConnectorEmailJaxb email;
	
	public ConnectorJaxb() {
	}

	@XmlElement(name = "id")
	public String getId() {
		return id;
	}

	public void setId(String id) {
		this.id = id;
	}

	public String getConnectorFactoryClassName() {
		return connectorFactoryClassName;
	}

	public void setConnectorFactoryClassName(String connectorFactoryClassName) {
		this.connectorFactoryClassName = connectorFactoryClassName;
	}

	public Integer getRetries() {
		return retries;
	}

	public void setRetries(Integer retries) {
		this.retries = retries;
	}

	public String getIntervals() {
		return intervals;
	}

	public void setIntervals(String intervals) {
		this.intervals = intervals;
	}

	public ConnectorEmailJaxb getEmail() {
		return email;
	}

	public void setEmail(ConnectorEmailJaxb emailJaxb) {
		this.email= emailJaxb;
	}

	public ConnectorCredentialJaxb getCredential() {
		return credential;
	}

	public void setCredential(ConnectorCredentialJaxb credential) {
		this.credential = credential;
	}

	@Override
	public String toString() {
		return "ConnectorJaxb [id=" + id + ", connectorFactoryClassName="
				+ connectorFactoryClassName + ", retries=" + retries
				+ ", intervals=" + intervals + ", credential=" + credential
				+ ", email=" + email + "]";
	}
	
}
