package com.travelex.notifier.exception;


public class ConnectionException extends RuntimeException {

	private static final long serialVersionUID = 6714478413779525519L;

	public ConnectionException() {
		super();
	}

}
