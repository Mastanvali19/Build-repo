package com.travelex.notifier.facade;

import java.io.File;
import java.io.FileInputStream;
import java.io.FileWriter;
import java.io.IOException;
import java.io.PrintWriter;
import java.text.MessageFormat;
import java.util.Properties;

import javax.jms.Connection;
import javax.jms.ConnectionFactory;
import javax.jms.DeliveryMode;
import javax.jms.MapMessage;
import javax.jms.MessageProducer;
import javax.jms.Queue;
import javax.jms.Session;
import javax.naming.Context;
import javax.naming.InitialContext;
import javax.xml.bind.JAXBException;

import org.apache.log4j.Logger;
import org.xml.sax.SAXException;

import com.travelex.notifier.adapter.ServiceAdapter;
import com.travelex.notifier.adapter.ServiceAdapterCredentials;
import com.travelex.notifier.adapter.ServiceAdapterFactory;
import com.travelex.notifier.domain.ConnectorJaxb;
import com.travelex.notifier.exception.ConnectionException;


public class NotifierFacade {
	
	private static final Logger logger = Logger.getLogger(NotifierFacade.class);
	
	private static volatile NotifierFacade INSTANCE = new NotifierFacade();
    
	private static final String DIR = "/etc/notifier";
	
	private static Properties  errorNotification;

	private NotifierFacade() {
		reloadErrorNotificationConfig();		
	}

	private static ConnectorJaxb connector;

	public static NotifierFacade getInstance() {
		if(INSTANCE == null){
			synchronized(NotifierFacade.class){
				if(INSTANCE == null){
					INSTANCE = new NotifierFacade();
				}
			}
		}
		return INSTANCE;
	}

	public ConnectorJaxb getConnectorConfig(String id) throws NumberFormatException, SAXException, IOException, JAXBException {
		connector = ConnectorConfigFactory.getConnectorConfigFromFile(id);
		return connector;
	}
	
	/**
	 * Initialize by lazy loading the instance variable connector
	 * 
	 * @return The Connector
	 * @throws Throwable
	 */
	private ServiceAdapter getConnector(String id) throws Throwable {
		ConnectorJaxb conConfig = getConnectorConfig(id);
		if (conConfig == null) {
			logger.debug("Connector Configuration is null");
			return null;
		}
		String adapterFactoryName = conConfig.getConnectorFactoryClassName();

		Object adapterFactory = null;
		logger.debug("Instantiating adapterFactory");

		adapterFactory = Class.forName(adapterFactoryName).newInstance();
		logger.debug("Instantiating adapter");

		ServiceAdapterCredentials credentials = new ServiceAdapterCredentials(conConfig.getCredential().getTargetEndpoint(), conConfig.getCredential().getUsername(), conConfig.getCredential().getPassword());

		return ((ServiceAdapterFactory) adapterFactory).getAdapter(credentials);
	}

	public boolean notify(String id, String xml, String msgId) {
		boolean success = false;
		ServiceAdapter adapter = null;
		try {
			logger.debug("Sending activation command to the connector");
			try {
				adapter = getConnector(id);
				if (adapter == null) {
					logger.debug("The connector is returning null");
					throw new Exception();
				}
			} catch (Exception e) {
				logger.error("Notifier: Error trying to obtain the connector to the service:" + id + " [xml: " + xml + " msgId: " + msgId + "]");
				notifyError(id, xml, msgId);
				return false;
			}
			if (adapter != null) {
				logger.info("Notifier: Invoking method from the connector:"	+ adapter + "[MessageID:" + msgId + " [id: " + id+ " xml: " + xml + "]" + " System.currentTimeMillis:"+ System.currentTimeMillis() + "]");
				success = adapter.invoke(xml);
			}
			if (!success) {
				
				String mailSubject = getMailSubject();
				String mailContent = getMailBody();
				Object[] bodyParameters = adapter.getObjectsEmail(xml);
				logger.info("Sending email with the error to connector id: " + id + " xml:" + xml);
				sendEMail(id, mailSubject, mailContent, bodyParameters);
			}
		} catch (Throwable e) {
			success = false;
			logger.error("Notifier: Error processing the message: [MessageID:"+ msgId + " [id: " + id + " xml: " + xml + "]", e);
			throw new ConnectionException();
		}
		return success;
	}
	
	public void notifyFromDLQ(String id, String xml, String msgId) {
        ServiceAdapter adapter = null;
        try {
               logger.debug("Publishing email from NotifierDLQ to EmailQueue.");              
               adapter = getConnector(id);
               if (adapter == null) {
                  logger.error("The connector is returning null from NotifierDLQ");                                   
               }                     
               if (adapter != null) {
                   logger.info("Notifier: Publishing to email Queue from NotifierDLQ"   + adapter + "[MessageID:" + msgId + " [id: " + id+ " xml: " + xml + "]" + " System.currentTimeMillis:"+ System.currentTimeMillis() + "]");
                   
                   String mailSubject = NotifierFacade.getInstance().getMailSubject();
   					String mailContent = NotifierFacade.getInstance().getMailBody();
   					Object[] bodyParameters = adapter.getObjectsEmail(xml);
   					logger.info("Sending email with the error to connector id: " + id + " xml:" + xml);
   					sendEMail(id, mailSubject, mailContent, bodyParameters);
               }
        }catch(Throwable e){
        	logger.error("Exception while publishing to Email queue from Notifier DLQ " + e);
        }
      }
	
	public void notifyError(String id, String xml, String msgId) {
		try {
			String hostName = errorNotification.getProperty("host");
			String mailFrom = errorNotification.getProperty("from");
			String mailTo = errorNotification.getProperty("to");
			String contentType = errorNotification.getProperty("content");
			String subject = errorNotification.getProperty("subject");
			String mailContent = errorNotification.getProperty("body");

			xml = xml.replaceAll("<", "&lt;").replaceAll(">", "&gt;");

			Object[] bodyParameters = { id, xml, msgId };

			publishEmailQueue(subject, mailContent, bodyParameters, mailFrom,mailTo, contentType, hostName);
		} catch (Exception e) {
			throw new ConnectionException();
		}

	}
	
	
	public void reloadErrorNotificationConfig() {
		errorNotification = new Properties();

		try {
			errorNotification.load(new FileInputStream(DIR+ "/error-notification.properties"));
			logger.info("Error Notification Configuration has been loaded");
			logger.info("Error Notification Configuration = "
					+ errorNotification);
		} catch (IOException e) {
			logger.error(e);
		}

	}	
	 
	public void sendEMail(String id, String mailSubject, String mailContent, Object[] bodyParameters) throws NumberFormatException, SAXException, IOException, JAXBException {

		String mailFrom = connector.getEmail().getFrom();
		String mailTo = connector.getEmail().getTo();
		String contentType = connector.getEmail().getContent();
		String hostName = connector.getEmail().getHost();
		
		publishEmailQueue(mailSubject, mailContent, bodyParameters, mailFrom, mailTo, contentType, hostName);
	}
	
	private void publishEmailQueue(String mailSubject, String mailContent,Object[] bodyParameters, String mailFrom, String mailTo,String contentType, String hostName) {
		Context ic = null;
		ConnectionFactory cf = null;
		Connection connection = null;
		MapMessage messageemail = null;

		try {
			ic = new InitialContext();
			cf = (ConnectionFactory) ic.lookup("java:/jms/RemoteConnectionFactory");
			Queue queue = (Queue) ic.lookup("java:/jms/foxwebMailComponentQueue");
			connection = cf.createConnection();

			Session session = connection.createSession(false,Session.AUTO_ACKNOWLEDGE);
			MessageProducer sender = session.createProducer(queue);
			sender.setDeliveryMode(DeliveryMode.PERSISTENT);

			messageemail = session.createMapMessage();

			String content = MessageFormat.format(mailContent, bodyParameters);

			messageemail.setString("host", hostName);
			messageemail.setString("from", mailFrom);
			messageemail.setString("to", mailTo);
			messageemail.setString("subject", mailSubject);
			messageemail.setString("content", content);
			messageemail.setString("contentType", contentType);
			sender.send(messageemail);
			connection.start();

		} catch (Exception e) {
			logger.error("Failed to Publish message from notifierComponentQueue to FoxwebMailComponentQueue"+ messageemail);
			throw new ConnectionException();
		} finally {
			try {
				if (connection != null) {
					connection.close();
				}
				if (ic != null) {
					ic.close();
				}
			} catch (Exception e) {
				throw new ConnectionException();
			}
		}
	}

	public File createFile(String file, String content) throws IOException {
		File _file = new File(file);
		_file.createNewFile();
		FileWriter fw = new FileWriter(_file);
		PrintWriter pw = new PrintWriter(fw);
		pw.println(content);
		pw.close();
		fw.close();
		return _file;
	}
	
	public String[] getIntervals(String id) {
		return connector.getIntervals().split(",");
	}

	public int getRetries(String id) {
		return connector.getRetries();
	}

	public String getMailSubject() {
		return connector.getEmail().getSubject();
	}

	public String getMailBody() {
		return connector.getEmail().getBody();
	}
}