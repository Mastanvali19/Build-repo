package com.travelex.notifier.domain;

import java.io.Serializable;

import javax.xml.bind.annotation.XmlRootElement;
import javax.xml.bind.annotation.XmlType;

@XmlRootElement(name = "credentials")
@XmlType(propOrder = { "targetEndpoint", "username", "password"})
public class ConnectorCredentialJaxb implements Serializable {
	
	private static final long serialVersionUID = -2980391975390483301L;

	protected String targetEndpoint;
    protected String username;
    protected String password;
    
	public ConnectorCredentialJaxb() {
		super();
	}

	public String getTargetEndpoint() {
		return targetEndpoint;
	}

	public void setTargetEndpoint(String targetEndpoint) {
		this.targetEndpoint = targetEndpoint;
	}

	public String getUsername() {
		return username;
	}

	public void setUsername(String username) {
		this.username = username;
	}

	public String getPassword() {
		return password;
	}

	public void setPassword(String password) {
		this.password = password;
	}

	@Override
	public String toString() {
		return "ConnectorCredentialJaxb [targetEndpoint=" + targetEndpoint
				+ ", username=" + username + ", password=" + password + "]";
	}

}
