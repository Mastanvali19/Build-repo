package com.travelex.notifier.facade;

import java.io.FileNotFoundException;
import java.io.FileReader;
import java.io.IOException;
import java.util.ArrayList;
import java.util.Collection;

import javax.xml.bind.JAXBContext;
import javax.xml.bind.JAXBException;
import javax.xml.bind.Unmarshaller;

import org.apache.log4j.Logger;
import org.xml.sax.SAXException;

import com.travelex.memcached.DtoCacheManager;
import com.travelex.notifier.domain.ConnectorJaxb;
import com.travelex.notifier.domain.ConnectorsListJaxb;

public class ConnectorConfigFactory {
	private static final Logger logger = Logger	.getLogger(ConnectorConfigFactory.class);
	private static ArrayList<ConnectorJaxb> listaConectores;
	private static final String KEY = "Notifier.";

	private static final String DIR = "/etc/notifier/";
	
	public static ConnectorJaxb getConnectorConfigFromFile(String id) throws SAXException, IOException, JAXBException {
		logger.debug("Retrieving connector configuration: " + id);
		Collection<ConnectorJaxb> connectors = executeParsesJaxb();
		logger.info("Notifier: Collection<ConnectorJaxb>: [" + connectors.toString() + "]");
		for (ConnectorJaxb connectorConfig : connectors) {
			if (connectorConfig.getId().equals(id)) {
				logger.info("Notifier: Returning connector config:" + id + " connectorConfig: " + connectorConfig.toString());
				return connectorConfig;
			}
		}
		logger.info("Connector <"+id+"> Configuration Not Found");
		return null;
	}

	@SuppressWarnings("unchecked")
	private static ArrayList<ConnectorJaxb> executeParsesJaxb() throws JAXBException, FileNotFoundException {
		String key = KEY + "connectorConfigList";
		logger.info("Notifier: Trying to read the configurations from MEMCACHED");
		listaConectores = (ArrayList<ConnectorJaxb>) DtoCacheManager.get(key);
		if (listaConectores != null) {
			logger.info("Notifier: Configurations were at MEMCACHED!");
			return listaConectores;
		}
		
		logger.info("Notifier: Reading the configuration file from: " + DIR + "notifier-connector-config-jaxb.xml");
		// create JAXB context and instantiate marshaller
	    JAXBContext context = JAXBContext.newInstance(ConnectorsListJaxb.class);
	    Unmarshaller um = context.createUnmarshaller();
	    ConnectorsListJaxb cl = (ConnectorsListJaxb) um.unmarshal(new FileReader(DIR+"notifier-connector-config-jaxb.xml"));
	    listaConectores = cl.getConnectorsList();
	    DtoCacheManager.put(key, listaConectores);
		return listaConectores;
	}

}