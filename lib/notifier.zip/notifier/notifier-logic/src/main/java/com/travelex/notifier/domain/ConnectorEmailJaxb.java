package com.travelex.notifier.domain;

import java.io.Serializable;

import javax.xml.bind.annotation.XmlRootElement;
import javax.xml.bind.annotation.XmlType;

@XmlRootElement(name = "email")
@XmlType(propOrder = { "host","content","from","to","subject","body"})
public class ConnectorEmailJaxb implements Serializable {
	
	private static final long serialVersionUID = -7764149200307662529L;
	
	protected String host;
	protected String content;
	protected String from;
	protected String to;
	protected String subject;
	protected String body;

	public ConnectorEmailJaxb() {
		super();
	}
	
	public String getHost() {
		return host;
	}
	
	public void setHost(String host) {
		this.host = host;
	}
	
	public String getContent() {
		return content;
	}
	
	public void setContent(String content) {
		this.content = content;
	}
	
	public String getFrom() {
		return from;
	}
	
	public void setFrom(String from) {
		this.from = from;
	}
	
	public String getTo() {
		return to;
	}
	
	public void setTo(String to) {
		this.to = to;
	}
	
	public String getSubject() {
		return subject;
	}
	
	public void setSubject(String subject) {
		this.subject = subject;
	}
	
	public String getBody() {
		return body;
	}
	
	public void setBody(String body) {
		this.body = body;
	}

	@Override
	public String toString() {
		return "ConnectorEmailJaxb [host=" + host + ", content=" + content
				+ ", from=" + from + ", to=" + to + ", subject=" + subject
				+ ", body=" + body + "]";
	}
	
}
