package com.travelex.notifier.facade.test;

import com.travelex.notifier.facade.NotifierFacade;

public class FacadeTest {
	
	public static void main(String[] args){
		new FacadeTest().doTest();
	}
	
	public void doTest(){
		String id = "SALT2";
		String xml = "<EventMessage><action>procTrans</action><orderId>123456789</orderId><orderNo>4568852</orderNo><externalOrderNo>AU789456123</externalOrderNo><status>P</status></EventMessage>";
		String msgId = "msg123456789";
		
		//boolean result = NotifierFacade.getInstance().notify(id, xml, msgId, true,1);
		
	}
	
}
