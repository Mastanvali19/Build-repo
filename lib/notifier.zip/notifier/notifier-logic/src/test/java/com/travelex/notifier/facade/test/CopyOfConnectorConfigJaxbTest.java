package com.travelex.notifier.facade.test;

import java.io.FileReader;
import java.io.FileWriter;
import java.io.IOException;
import java.io.Writer;
import java.util.ArrayList;

import javax.xml.bind.JAXBContext;
import javax.xml.bind.JAXBException;
import javax.xml.bind.Marshaller;
import javax.xml.bind.Unmarshaller;

import com.travelex.notifier.domain.ConnectorJaxb;
import com.travelex.notifier.domain.ConnectorsListJaxb;

public class CopyOfConnectorConfigJaxbTest {
	
	private static final String BOOKSTORE_XML = "./connector-config-jaxb.xml";
	
	public static void main(String[] args) throws JAXBException, IOException {
//		ArrayList<ConnectorJaxb> list = new ArrayList<ConnectorJaxb>();
//		
//		ConnectorJaxb c1 = new ConnectorJaxb();
//		c1.setId("1");
//		c1.setRetries("4");
//		c1.setConnectorFactoryClassName("com.travelex.foxweb.notifier.client.salt.SaltAdapterFactory");
//		c1.setIntervals("5000,8000,10000");
//		c1.setEmail("foxweb_developers@travelex.com");
//		list.add(c1);
//
//		ConnectorJaxb c2 = new ConnectorJaxb();
//		c2.setId("2");
//		c2.setRetries("3");
//		c2.setConnectorFactoryClassName("com.travelex.foxweb.notifier.client.nab.NabAdapterFactory");
//		c2.setIntervals("5000,8000,10000");
//		c2.setEmail("foxweb_developers@travelex.com");
//		list.add(c2);
//		
//		ConnectorsListJaxb cl = new ConnectorsListJaxb();
//		cl.setConnectorList(list);
//		
//		// create JAXB context and instantiate marshaller
	    JAXBContext context = JAXBContext.newInstance("com.travelex.notifier.domain");
//	    Marshaller m = context.createMarshaller();
//	    m.setProperty(Marshaller.JAXB_FORMATTED_OUTPUT, Boolean.TRUE);
//	    m.marshal(cl, System.out);
//
//	    Writer w = null;
//	    try {
//	      w = new FileWriter(BOOKSTORE_XML);
//	      m.marshal(cl, w);
//	    } finally {
//	      try {
//	        w.close();
//	      } catch (Exception e) {
//	      }
//	    }

	    // get variables from our xml file, created before
	    System.out.println();
	    System.out.println("Output from our XML File: ");
	    Unmarshaller um = context.createUnmarshaller();
	    ConnectorsListJaxb cl2 = (ConnectorsListJaxb) um.unmarshal(new FileReader(BOOKSTORE_XML));

	    for (int i = 0; i < cl2.getConnectorsList().toArray().length; i++) {
	      System.out.println("Book " + (i + 1) + ": "
	          + cl2.getConnectorsList().get(i).getId() + " from "
	          + cl2.getConnectorsList().get(i).getConnectorFactoryClassName());
	    }
		
	}
	
}
