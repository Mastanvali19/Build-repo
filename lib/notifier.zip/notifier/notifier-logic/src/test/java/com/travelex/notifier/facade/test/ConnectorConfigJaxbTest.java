package com.travelex.notifier.facade.test;

import java.io.FileReader;
import java.io.FileWriter;
import java.io.IOException;
import java.io.Writer;
import java.util.ArrayList;

import javax.xml.bind.JAXBContext;
import javax.xml.bind.JAXBException;
import javax.xml.bind.Marshaller;
import javax.xml.bind.Unmarshaller;

import com.travelex.notifier.domain.ConnectorCredentialJaxb;
import com.travelex.notifier.domain.ConnectorEmailJaxb;
import com.travelex.notifier.domain.ConnectorJaxb;
import com.travelex.notifier.domain.ConnectorsListJaxb;

public class ConnectorConfigJaxbTest {
	
	private static final String BOOKSTORE_XML = "./connector-config-jaxb.xml";
	
	public static void main(String[] args) throws JAXBException, IOException {
		ArrayList<ConnectorJaxb> list = new ArrayList<ConnectorJaxb>();
		
		ConnectorJaxb c1 = new ConnectorJaxb();
		c1.setId("SALT");
		c1.setRetries(4);
		c1.setConnectorFactoryClassName("com.travelex.foxweb.notifier.client.salt.SaltAdapterFactory");
		c1.setIntervals("5000,8000,10000");
		
		ConnectorCredentialJaxb cr1 = new ConnectorCredentialJaxb();
		cr1.setTargetEndpoint("http://localhost:8090/axis2/services/Order");
		cr1.setUsername(null);
		cr1.setPassword(null);
		c1.setCredential(cr1);
		
		
		ConnectorEmailJaxb e1 = new ConnectorEmailJaxb();
		e1.setTo("foxweb_developers@travelex.com");
		e1.setFrom("gustavo.garcia@travelex.com");
		e1.setHost("AU-SYD-EX-VS1.apac.travelex.net");
		e1.setContent("text/html");
		e1.setBody("This is a test email. Please do not reply");
		e1.setSubject("Test Email");
		c1.setEmail(e1);

		list.add(c1);

		ConnectorJaxb c2 = new ConnectorJaxb();
		c2.setId("NAB");
		c2.setRetries(3);
		c2.setConnectorFactoryClassName("com.travelex.foxweb.notifier.client.nab.NabAdapterFactory");
		c2.setIntervals("5000,8000,10000");
		
		ConnectorCredentialJaxb cr2 = new ConnectorCredentialJaxb();
		cr2.setTargetEndpoint("http://localhost:8090/axis2/services/Order");
		cr2.setUsername(null);
		cr2.setPassword(null);
		c2.setCredential(cr2);
		
		ConnectorEmailJaxb e2 = new ConnectorEmailJaxb();
		e2.setTo("foxweb_developers@travelex.com");
		e2.setFrom("gustavo.garcia@travelex.com");
		e2.setHost("AU-SYD-EX-VS1.apac.travelex.net");
		e2.setContent("text/html");
		e2.setBody("This is a test email. Please do not reply");
		e2.setSubject("Test Email");
		c2.setEmail(e2);
		
		list.add(c2);
		
		ConnectorsListJaxb cl = new ConnectorsListJaxb();
		cl.setConnectorList(list);
		
		// create JAXB context and instantiate marshaller
	    JAXBContext context = JAXBContext.newInstance(ConnectorsListJaxb.class);
	    Marshaller m = context.createMarshaller();
	    m.setProperty(Marshaller.JAXB_FORMATTED_OUTPUT, Boolean.TRUE);
	    m.marshal(cl, System.out);

	    Writer w = null;
	    try {
	      w = new FileWriter(BOOKSTORE_XML);
	      m.marshal(cl, w);
	    } finally {
	      try {
	        w.close();
	      } catch (Exception e) {
	      }
	    }

	    // get variables from our xml file, created before
	    System.out.println();
	    System.out.println("Output from our XML File: ");
	    Unmarshaller um = context.createUnmarshaller();
	    ConnectorsListJaxb cl2 = (ConnectorsListJaxb) um.unmarshal(new FileReader(BOOKSTORE_XML));

	    for (int i = 0; i < cl2.getConnectorsList().toArray().length; i++) {
	      System.out.println("Book " + (i + 1) + ": "
	          + cl2.getConnectorsList().get(i).getId() + " from "
	          + cl2.getConnectorsList().get(i).getConnectorFactoryClassName());
	    }
		
	}
	
}
