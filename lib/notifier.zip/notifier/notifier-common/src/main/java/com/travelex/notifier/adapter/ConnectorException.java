package com.travelex.notifier.adapter;

import java.io.PrintStream;
import java.io.PrintWriter;

public class ConnectorException extends Exception {

    private static final long serialVersionUID = 1L;

    /** 
     * Property that contains the cause stackTrace of the exception. <br>
     * Must be transient to avoid remote communication problems, where destiny JVM
     * should not have the class that generates the exception.
     */
    private transient Throwable cause;

    /**
     * Constructor for ConnectorException.
     */
    public ConnectorException() {
        super();
    }

    /**
     * Constructor for ConnectorException.
     * @param s
     */
    public ConnectorException(String s) {
        super(s);
    }

    /**
     * @param t Nested throwable object.
     */
    public ConnectorException(Throwable t) {
        super(t.getLocalizedMessage());
        this.cause = t;
    }

    /**
     * @param msg
     * @param t Nested throwable object.
     */
    public ConnectorException(String msg, Throwable t) {
        super(msg);
        this.cause = t;
    }
    
    /**
     * @return Throwable object representing the cause of the exception
     */
    public Throwable getCause() {
        return this.cause;
    }

    /**
     * Print the exception to <code>System.out</code>.
     *
     * @see java.lang.Throwable#printStackTrace()
     */
    public void printStackTrace() {
        this.printStackTrace(System.out);
    }

    /**
     * Print the exception
     *
     * @param s
     * @see java.lang.Throwable#printStackTrace(java.io.PrintStream)
     */
    public void printStackTrace(PrintStream s) {
        this.printStackTrace(new PrintWriter(s));
    }

    /**
     * Print the exception and the cause, if exists.
     *
     * @param s
     * @see java.lang.Throwable#printStackTrace(java.io.PrintWriter)
     */
    public void printStackTrace(PrintWriter s) {
        super.printStackTrace(s);
        if (this.cause != null) {
            s.println("Caused by: " + getCause().getClass().getName() );
            getCause().printStackTrace(s);
        }
    }
    
}
