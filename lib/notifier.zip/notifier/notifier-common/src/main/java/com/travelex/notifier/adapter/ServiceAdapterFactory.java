package com.travelex.notifier.adapter;

public interface ServiceAdapterFactory {
	
	public ServiceAdapter getAdapter(ServiceAdapterCredentials credentials) throws ConnectorException;
	
}
