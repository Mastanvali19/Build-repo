package com.travelex.notifier.adapter;

import java.io.Serializable;

public class ServiceAdapterCredentials implements Serializable{

	private static final long serialVersionUID = 1L;
	
	protected String targetEndpoint;
	protected String username; 
	protected String password;
	
	public ServiceAdapterCredentials() {
		super();
	}

	public ServiceAdapterCredentials(String targetEndpoint, String username, String password) {
		super();
		this.targetEndpoint = targetEndpoint;
		this.username = username;
		this.password = password;
	}

	public String getTargetEndpoint() {
		return targetEndpoint;
	}

	public void setTargetEndpoint(String targetEndpoint) {
		this.targetEndpoint = targetEndpoint;
	}

	public String getUsername() {
		return username;
	}

	public void setUsername(String username) {
		this.username = username;
	}

	public String getPassword() {
		return password;
	}

	public void setPassword(String password) {
		this.password = password;
	}

	public int hashCode() {
		final int prime = 31;
		int result = 1;
		result = prime * result
				+ ((password == null) ? 0 : password.hashCode());
		result = prime * result
				+ ((targetEndpoint == null) ? 0 : targetEndpoint.hashCode());
		result = prime * result
				+ ((username == null) ? 0 : username.hashCode());
		return result;
	}

	public boolean equals(Object obj) {
		if (this == obj)
			return true;
		if (obj == null)
			return false;
		if (getClass() != obj.getClass())
			return false;
		ServiceAdapterCredentials other = (ServiceAdapterCredentials) obj;
		if (password == null) {
			if (other.password != null)
				return false;
		} else if (!password.equals(other.password))
			return false;
		if (targetEndpoint == null) {
			if (other.targetEndpoint != null)
				return false;
		} else if (!targetEndpoint.equals(other.targetEndpoint))
			return false;
		if (username == null) {
			if (other.username != null)
				return false;
		} else if (!username.equals(other.username))
			return false;
		return true;
	}

	public String toString() {
		return "ServiceAdapterCredentials [targetEndpoint=" + targetEndpoint + ", username=" + username + ", password=" + password + "]";
	} 
	
}
