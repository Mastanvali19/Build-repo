package com.travelex.notifier.adapter;

public abstract class ServiceAdapter {
	
	protected ServiceAdapterCredentials credentials;
	
	public ServiceAdapter(ServiceAdapterCredentials credentials){
		this.credentials = credentials;
	}
	
	public abstract boolean invoke(String xml) throws ConnectorException;
	
	public abstract Object[] getObjectsEmail(String xml);
	
}
