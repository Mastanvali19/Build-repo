package com.travelex.notifier.client.ctrip.orderupdate.dao;


public interface CtripOrderUpdateDao {

	public String getUniqueTransId();
}
