package com.travelex.notifier.client.ctrip.orderupdate;

import org.springframework.context.ApplicationContext;

import com.travelex.notifier.adapter.ConnectorException;
import com.travelex.notifier.adapter.ServiceAdapter;
import com.travelex.notifier.adapter.ServiceAdapterCredentials;
import com.travelex.notifier.adapter.ServiceAdapterFactory;

public class CtripOrderUpdateAdapterFactory implements ServiceAdapterFactory {

	@Override
	public ServiceAdapter getAdapter(ServiceAdapterCredentials credentials)
			throws ConnectorException {
		
			ApplicationContext context = null;
		 
			return new CtripOrderUpdateAdapterImpl(credentials,context);
	}

}
