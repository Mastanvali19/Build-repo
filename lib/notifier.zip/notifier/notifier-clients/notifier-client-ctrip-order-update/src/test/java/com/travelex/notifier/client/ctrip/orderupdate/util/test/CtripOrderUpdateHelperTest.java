package com.travelex.notifier.client.ctrip.orderupdate.util.test;

import static org.junit.Assert.assertEquals;

import org.junit.AfterClass;
import org.junit.BeforeClass;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.mockito.runners.MockitoJUnitRunner;
import org.springframework.context.ApplicationContext;
import org.springframework.context.support.ClassPathXmlApplicationContext;

import com.travelex.notifier.client.ctrip.orderupdate.dao.CtripOrderUpdateDaoImpl;
import com.travelex.notifier.client.ctrip.orderupdate.util.CtripOrderUpdateHelper;

@RunWith(MockitoJUnitRunner.class)
public class CtripOrderUpdateHelperTest {

	private static CtripOrderUpdateHelper helper;
	private static ApplicationContext context;
	
	@BeforeClass
	public static void setup(){
		context = new ClassPathXmlApplicationContext("classpath:test-applicationContext.xml");
		helper = new CtripOrderUpdateHelper();
		
	}
	
	@Test
	public void testGetUniqueTransID(){
		assertEquals(helper.getUniqueTransID(context),"0000000001");
		
	}
	
	@Test
	public void testProcessTransID(){
		assertEquals(helper.processTransactionId("ABC"),"0000000ABC");
		assertEquals(helper.processTransactionId("12"), "0000000012");
	}
	
	//@Test(expected=Exception.class)
	public void processTransIdThrowsException(){
		helper.processTransactionId(null);
	}
	
	@AfterClass
	public static void tearDown(){
		CtripOrderUpdateDaoImpl dao = (CtripOrderUpdateDaoImpl) context.getBean("ctripTransIdentityDao");
		dao.getJdbcTemplate().execute("DROP TABLE TABLE_IDS");
		context = null;
		helper = null;
	}
}
