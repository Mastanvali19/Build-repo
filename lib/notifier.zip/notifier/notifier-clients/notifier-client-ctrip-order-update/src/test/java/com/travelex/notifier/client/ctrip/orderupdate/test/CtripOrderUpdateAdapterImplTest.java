package com.travelex.notifier.client.ctrip.orderupdate.test;

import static org.junit.Assert.assertEquals;
import static org.junit.Assert.assertNotNull;
import static org.mockito.Matchers.anyString;
import static org.mockito.Mockito.spy;
import static org.mockito.Mockito.when;

import java.util.Date;
import java.util.Properties;

import org.junit.AfterClass;
import org.junit.BeforeClass;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.mockito.Mockito;
import org.mockito.runners.MockitoJUnitRunner;
import org.springframework.context.ApplicationContext;
import org.springframework.context.support.ClassPathXmlApplicationContext;

import com.ctrip.soa.financialservices.forex.forexvendorservice.types.v1.OrderStatusSyncRequest;
import com.ctrip.soa.financialservices.forex.forexvendorservice.types.v1.OrderStatusSyncResponse;
import com.ctrip.soa.financialservices.forex.forexvendorservice.types.v1.RequestCommon;
import com.ctrip.soa.financialservices.forex.forexvendorservice.types.v1.ResponseCommon;
import com.ctrip.soa.financialservices.forex.forexvendorservice.v1.ForexVendorServiceInterface;
import com.travelex.notifier.adapter.ConnectorException;
import com.travelex.notifier.adapter.ServiceAdapterCredentials;
import com.travelex.notifier.client.ctrip.orderupdate.CtripOrderUpdateAdapterImpl;
import com.travelex.notifier.client.ctrip.orderupdate.dao.CtripOrderUpdateDaoImpl;

@RunWith(MockitoJUnitRunner.class)
public class CtripOrderUpdateAdapterImplTest {
	
	
	private static ForexVendorServiceInterface vendorService;
	private static ServiceAdapterCredentials credentials;
	private static CtripOrderUpdateDaoImpl dao;
	private static ApplicationContext context;
	private static CtripOrderUpdateAdapterImpl ctripAdapterImpl;
	
	@BeforeClass
	public static void setUp(){
		credentials = Mockito.mock(ServiceAdapterCredentials.class);
		context = new ClassPathXmlApplicationContext("classpath:test-applicationContext.xml");
		ctripAdapterImpl = new CtripOrderUpdateAdapterImpl(credentials,context);

		vendorService = Mockito.mock(ForexVendorServiceInterface.class);
		assertNotNull(vendorService);
	}
	
	@Test	
	public void testLoadProperties(){
		Properties prop = Mockito.mock(Properties.class);
		when(prop.getProperty(anyString())).thenReturn("password");
	}
	
	//@Test(expected=Exception.class)
	public void testInvoke() throws ConnectorException{
	
		String xml = "<?xml version=\"1.0\" encoding=\"UTF-8\" standalone=\"yes\"?><EventMessage xmlns=\"http://travelex.org/foxweb/\"><OrderUpdateEventMessage><action>procTrans</action><orderId>1</orderId><orderNo>1</orderNo><externalOrderNo>1</externalOrderNo><status>P</status><customerName>ABC</customerName></OrderUpdateEventMessage></EventMessage>";
		//testFindRequestType();
		
		OrderStatusSyncResponse orderStatusResponse = new OrderStatusSyncResponse();
		orderStatusResponse.setResponseCommon(buildSuccessCommonResponse("9"));
		OrderStatusSyncRequest request = new OrderStatusSyncRequest();
		OrderStatusSyncRequest spy = spy(request);
		when(vendorService
				.orderStatusSync(spy)).thenReturn(orderStatusResponse);
		assertEquals(ctripAdapterImpl.invoke(xml),false);
		
	}
	
	@Test
	public void getObjectsEmail(){
		String xml = "<?xml version=\"1.0\" encoding=\"UTF-8\" standalone=\"yes\"?><EventMessage xmlns=\"http://travelex.org/foxweb/\"><OrderUpdateEventMessage><action>procTrans</action><orderId>1</orderId><orderNo>1</orderNo><externalOrderNo>1</externalOrderNo><status>P</status><customerName>ABC</customerName></OrderUpdateEventMessage></EventMessage>";
		assertNotNull(ctripAdapterImpl.getObjectsEmail(xml));
	}
	
	/*@Test
	public void testBuildRatesUpdateEmail(){
		String xml = "<?xml version=\"1.0\" encoding=\"UTF-8\" standalone=\"yes\"?><EventMessage xmlns=\"http://travelex.org/foxweb/\"><RatesUpdateEventMessage><rate><rate>6.4560</rate><transactionType>ORD</transactionType><transactionTypeDescription>Order</transactionTypeDescription><productCode>CCN</productCode><productCodeDescription>Foreign Cash</productCodeDescription><currencyCode>USD</currencyCode><currencyCodeDescription>U.S. Dollar</currencyCodeDescription><rateUnits>1</rateUnits><entityCode>919</entityCode></rate></RatesUpdateEventMessage></EventMessage>";
		assertNotNull(ctripAdapterImpl.getObjectsEmail(xml));		
	}*/
	@Test
	public void testFindRequestType(){
		String xml = "<?xml version=\"1.0\" encoding=\"UTF-8\" standalone=\"yes\"?><EventMessage xmlns=\"http://travelex.org/foxweb/\"><OrderUpdateEventMessage><action>procTrans</action><orderId>1</orderId><orderNo>1</orderNo><externalOrderNo>1</externalOrderNo><status>P</status><customerName>ABC</customerName></OrderUpdateEventMessage></EventMessage>";
		assertEquals(ctripAdapterImpl.findRequestType(xml),"OrderUpdateEventMessage");
		//verify(ctripAdapterImpl,atLeastOnce()).findRequestType(xml);
	}
	
	private RequestCommon buildRequestCommonType() {
		RequestCommon requestCommonType = new RequestCommon();
		requestCommonType.setTransID("0000000009ABCD");
		requestCommonType.setVendorCode("SupplierID");
		requestCommonType.setVendorPassword("password");
		requestCommonType.setReqTime(new Date().toString());
		
		return requestCommonType;
	}

	private ResponseCommon buildSuccessCommonResponse(String transID){
	    	ResponseCommon res = new ResponseCommon();
	    	res.setTransID(transID);
	    	res.setResCode("000000");
	    	res.setResDes("Success");
	    	res.setRspTime(new Date().toString());
	    	return res;
	    }
	
	@Test
	public void testInvokeOrderService() {
		
		OrderStatusSyncRequest request = new OrderStatusSyncRequest();
		request.setRequestCommon(buildRequestCommonType());
		OrderStatusSyncResponse orderStatusResponse = new OrderStatusSyncResponse();
		
		orderStatusResponse.setResponseCommon(buildSuccessCommonResponse(request.getRequestCommon().getTransID()));
		when(vendorService.orderStatusSync(request)).thenReturn(orderStatusResponse);
		assertEquals(orderStatusResponse.getResponseCommon().getTransID(), request.getRequestCommon().getTransID());
		
	}
	
	/*@Test
	public void testInvokeRatesUpdate() throws ConnectorException{
		SettlementCurrencySyncRequest request = new SettlementCurrencySyncRequest();
		request.setRequestCommon(buildRequestCommonType());
		SettlementCurrencySyncResponse response = new SettlementCurrencySyncResponse();
		response.setResponseCommon(buildSuccessCommonResponse(request.getRequestCommon().getTransID()));
		when(vendorService.settlementCurrencySync(request)).thenReturn(response);
		assertEquals(response.getResponseCommon().getTransID(), request.getRequestCommon().getTransID());
	}*/
	
	/*@Test
	public void testMapRates(){
		List<RateType> ratesList = new ArrayList<RateType>();
		List<RateType> spy = Mockito.spy(ratesList);
		spy.add(buildRate("USD","U.S. Dollar","CCN","Foreign Cash","ORD","Order",1,"6.4560","919"));
		spy.add(buildRate("HKD","British Pound","CCN","Foreign Cash","RTN","Order",1,"4.7839","800"));
		spy.add(buildRate("ABN","British Pound","CCN","Foreign Cash","RTN","Order",1,"0.7839","919"));
		spy.add(buildRate("EUR","Euro","CCN","Foreign Cash","ORD","Order",1,"7.0827","900"));
		spy.add(buildRate("USD","U.S. Dollar","CCN","Foreign Cash","RTN","Order",1,"2.4560","919"));
		SettlementCurrencySyncRequest vendorCurrencyRequest = new SettlementCurrencySyncRequest();
		ctripAdapterImpl.mapRatesUpdateRequest(spy,vendorCurrencyRequest);
		assertTrue(vendorCurrencyRequest.getCurrencySyncList().size()>2);
		assertEquals(vendorCurrencyRequest.getCurrencySyncList().get(0).getBranchCode(), "919");
	}*/
	/*private RateType buildRate(String currencyCode, String currencyDesc, String productCode, String productDesc, String transactionType, String transactionTypeDesc, Integer units, String rateValue, String entityCode) {
		RateType rate = new RateType();
		
		rate.setCurrencyCode(currencyCode);
		rate.setCurrencyCodeDescription(currencyDesc);
		rate.setProductCode(productCode);
		rate.setProductCodeDescription(productDesc);
		rate.setRateUnits(units);
		rate.setTransactionType(transactionType);
		rate.setTransactionTypeDescription(transactionTypeDesc);
		rate.setRate(new BigDecimal(rateValue));
		rate.setEntityCode(entityCode);
		return rate;
	}*/

	@AfterClass
	public static void tearDown(){
	
		dao = (CtripOrderUpdateDaoImpl) context.getBean("ctripTransIdentityDao");
		dao.getJdbcTemplate().execute("DROP TABLE TABLE_IDS");
		context = null;
		ctripAdapterImpl = null;
	}
}



