package com.travelex.notifier.client.ctrip.orderupdate.dao.test;

import static org.junit.Assert.assertEquals;
//import org.springframework.mock.jndi; 
import static org.junit.Assert.assertNotNull;
import static org.mockito.Mockito.spy;
import static org.mockito.Mockito.times;
import static org.mockito.Mockito.verify;
import static org.mockito.Mockito.when;

import java.math.BigDecimal;

import org.junit.After;
import org.junit.BeforeClass;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.mockito.runners.MockitoJUnitRunner;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.jdbc.datasource.embedded.EmbeddedDatabase;
import org.springframework.jdbc.datasource.embedded.EmbeddedDatabaseBuilder;

import com.travelex.notifier.client.ctrip.orderupdate.dao.CtripOrderUpdateDaoImpl;

@RunWith(MockitoJUnitRunner.class)
public class CtripOrderUpdateDaoTest {

	private static EmbeddedDatabase database;
	private static CtripOrderUpdateDaoImpl daoImpl;
	
	private static final String RETRIEVE_TRANS_ID = "SELECT TOP 1 table_id FROM table_ids WHERE table_name like 'CTRIPWS'";
	
	@BeforeClass
	public static void setup(){
		database = new EmbeddedDatabaseBuilder().addDefaultScripts().build();
		assertNotNull(database);
		daoImpl = new CtripOrderUpdateDaoImpl();
		daoImpl.setDataSource(database);
		assertNotNull(daoImpl);
	}
	
	@Test
	public void testGetTransactionUniqueId(){
		daoImpl.getJdbcTemplate().execute("INSERT INTO TABLE_IDS VALUES(0,'CTRIPWS')");
		//assertNotNull(daoImpl.getUniqueTransId());
		
		JdbcTemplate template = spy(daoImpl.getJdbcTemplate());
		
		BigDecimal max = new BigDecimal("9999999999");
		when(template.queryForObject(RETRIEVE_TRANS_ID, BigDecimal.class)).thenReturn(max);
		assertEquals(daoImpl.getUniqueTransId(),"1");
		
		verify(template,times(1)).queryForObject(RETRIEVE_TRANS_ID, BigDecimal.class);
		assertEquals(daoImpl.getUniqueTransId(),"2");
	}
	
	@After
	public void tearDown(){
		
		database.shutdown();
		daoImpl = null;
	}
}
