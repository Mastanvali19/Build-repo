package com.travelex.notifier.client.ctrip.orderupdate;

import java.io.FileInputStream;
import java.io.IOException;
import java.io.StringReader;
import java.io.StringWriter;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.HashMap;
import java.util.Map;
import java.util.Properties;

import javax.xml.bind.JAXBContext;
import javax.xml.bind.JAXBException;
import javax.xml.bind.Marshaller;
import javax.xml.datatype.XMLGregorianCalendar;
import javax.xml.parsers.DocumentBuilder;
import javax.xml.parsers.DocumentBuilderFactory;
import javax.xml.parsers.ParserConfigurationException;

import org.apache.cxf.interceptor.LoggingInInterceptor;
import org.apache.cxf.interceptor.LoggingOutInterceptor;
import org.apache.cxf.jaxrs.client.ClientConfiguration;
import org.apache.cxf.jaxrs.client.WebClient;
import org.apache.log4j.Logger;
import org.springframework.context.ApplicationContext;
import org.springframework.context.support.ClassPathXmlApplicationContext;
import org.w3c.dom.Document;
import org.xml.sax.InputSource;
import org.xml.sax.SAXException;

import com.ctrip.soa.financialservices.forex.forexvendorservice.v1.OrderStatusSyncRequest;
import com.ctrip.soa.financialservices.forex.forexvendorservice.v1.OrderStatusSyncResponse;
import com.ctrip.soa.financialservices.forex.forexvendorservice.types.v1.RequestCommon;
import com.ctrip.soa.financialservices.forex.forexvendorservice.types.v1.ResponseCommon;
import com.travelex.notifier.adapter.ConnectorException;
import com.travelex.notifier.adapter.ServiceAdapter;
import com.travelex.notifier.adapter.ServiceAdapterCredentials;
import com.travelex.notifier.client.EventMessageHelper;
import com.travelex.notifier.client.conf.EventMessage;
import com.travelex.notifier.client.conf.OrderUpdateEventMessage;
import com.travelex.notifier.client.ctrip.orderupdate.util.CtripOrderUpdateHelper;

public class CtripOrderUpdateAdapterImpl extends ServiceAdapter {

	private static final Logger logger = Logger.getLogger(CtripOrderUpdateAdapterImpl.class);
	public static final String UPDATE_ORDER = "OrderUpdateEventMessage";
	public static final String UPDATE_RATES = "RatesUpdateEventMessage";
	private static Properties  ctripSecurity;
	private static final String DIR = "/etc/notifier/ctrip";
	protected Map<String, String> status;
	protected Map<String, String> statusDescription;
	protected ApplicationContext context;
	
	protected Map<String, String> errorCodes;
	
	public CtripOrderUpdateAdapterImpl(ServiceAdapterCredentials credentials,ApplicationContext context) {
		
		super(credentials);
		if(context == null){
			context = new ClassPathXmlApplicationContext("classpath:applicationContext-orderupdate.xml");
		}
		this.context = context;
		getProperties();
		initializeMapObjects();
		
	}
	
	@Override
	public boolean invoke(String xml) throws ConnectorException {
		
		logger.info("invoke xml:[" + xml + "]");
		//String requestType = findRequestType(xml);
		EventMessageHelper eventMessageHelper = new EventMessageHelper();
		EventMessage message = eventMessageHelper.parseMessage(xml);
		
		if(message!= null && message.getOrderUpdateEventMessage() != null ){
			//if (requestType.equals(UPDATE_ORDER)) {
			OrderUpdateEventMessage orderMessage = message.getOrderUpdateEventMessage();
			return invokeOrderUpdateService(orderMessage);
			/*} else if (requestType.equals(UPDATE_RATES)) {
				RatesUpdateEventMessage ratesMessage = message
						.getRatesUpdateEventMessage();
				return invokeRatesUpdateService(ratesMessage);
			}*/
		}else{
			logger.error("Error invoking CTRIP - ORDER UPDATE notifier: Invalid update order request.");
			throw new IllegalArgumentException("Error invoking CTRIP - ORDER UPDATE notifier: Invalid update order request.");
		}
	}

	public boolean invokeOrderUpdateService(
			OrderUpdateEventMessage orderMessage) {

		if(!status.containsKey(orderMessage.getStatus())){
			logger.info("CTRIP notification is not required for this Foxweb status and is not mapped in notifier app. Order No :  "+ orderMessage.getOrderNo() +" and status : "+ orderMessage.getStatus());
			return true;
		}
		
		boolean success = false;
		OrderStatusSyncRequest orderstatusRequest = buildOrderStatusRequest(orderMessage);
		
		logOrderStatusRequestPayload(orderstatusRequest);
		try{
			WebClient vendorService = createServiceClient();
			OrderStatusSyncResponse orderStatusResponse = vendorService.post(orderstatusRequest,OrderStatusSyncResponse.class);
			
			if (orderStatusResponse != null && orderStatusResponse.getResponseCommon() != null) {
				success = handleResponseCodes("OrderStatusSyncResponse",orderStatusResponse.getResponseCommon());
			}
		}catch(Exception e){
			logger.error("Error invoking CTRIP - ORDER UPDATE notifier: ",e);
		}
		
		return success;

	}

	private void logOrderStatusRequestPayload(OrderStatusSyncRequest orderstatusRequest) {
		
		StringWriter writer = new StringWriter();
		JAXBContext context;
		try {
			context = JAXBContext.newInstance(OrderStatusSyncRequest.class);
			Marshaller m = context.createMarshaller();
			m.marshal(orderstatusRequest, writer);
			logger.info("CTRIP OrderStatusSync request payload: [ " + writer.toString() + "]");
		} catch (JAXBException e) {
			logger.error("Error marshalling Order status sync request payload for logging.",e);
		}      
		
	}

	protected WebClient createServiceClient() {
		WebClient client = WebClient.create(credentials.getTargetEndpoint(), credentials.getUsername(), credentials.getPassword(), null);
		ClientConfiguration config = WebClient.getConfig(client);
		config.getInInterceptors().add(new LoggingInInterceptor());
		config.getOutInterceptors().add(new LoggingOutInterceptor());
		return client;
	}
	
	protected OrderStatusSyncRequest buildOrderStatusRequest(OrderUpdateEventMessage orderMessage) {
		OrderStatusSyncRequest orderstatusRequest = new OrderStatusSyncRequest();

		RequestCommon requestCommonType = buildCommonRequest(orderMessage.getUpdateDateTime());

		orderstatusRequest.setRequestCommon(requestCommonType);
		if(isValid(orderMessage.getExternalOrderNo()) && isValid(orderMessage.getOrderNo()) && isValid(orderMessage.getStatus())){
			orderstatusRequest.setCtripOrderId(orderMessage.getExternalOrderNo());
			orderstatusRequest.setOrderStatus(Short.parseShort(status.get(orderMessage.getStatus())));
			orderstatusRequest.setVendorReferId(orderMessage.getOrderNo());
		}else{
			logger.error("Error invoking CTRIP - ORDER UPDATE notifier: Invalid or empty values in Order update request. Please check the request XML from Foxweb.");
			throw new IllegalArgumentException("Error invoking CTRIP - ORDER UPDATE notifier: Invalid or empty values in Order update request. Please check the request XML from Foxweb.");
		}

		return orderstatusRequest;
	}
	

	protected RequestCommon buildCommonRequest(XMLGregorianCalendar updateDateTime) {
		RequestCommon requestCommonType = new RequestCommon();
		Date date = null;
		// Foxweb sends order updated time
		if(updateDateTime!= null){
			date = updateDateTime.toGregorianCalendar().getTime();
		}else{
			date = new Date();
		}
		 
		SimpleDateFormat sdf = new SimpleDateFormat("yyyyMMddHHmmss");
		requestCommonType.setReqTime(sdf.format(date));

		CtripOrderUpdateHelper helper = new CtripOrderUpdateHelper();
		String uniqueTenDigitID = helper.getUniqueTransID(context);
		String vendorCode = ctripSecurity.getProperty("vendorCode");
		String vendorPassword = ctripSecurity.getProperty("vendorPassword");
		
		if(!(isValid(vendorCode) && isValid(vendorPassword))){
			logger.error("Error invoking CTRIP - ORDER UPDATE notifier: Invalid security parameters in CTRIP configuration [ vendorCode: "+ vendorCode + " vendorPassword: "+vendorPassword + " ]");
			throw new IllegalArgumentException("Error invoking CTRIP - ORDER UPDATE notifier: Invalid security parameters in CTRIP configuration.");
		}
		
		requestCommonType.setVendorCode(vendorCode);
		requestCommonType.setVendorPassword(vendorPassword);
		
		if(isValid(uniqueTenDigitID)){
			StringBuffer transId = new StringBuffer();
			SimpleDateFormat sdFormat = new SimpleDateFormat("yyyyMMdd");
			transId.append(vendorCode).append(sdFormat.format(date)).append(uniqueTenDigitID);
			requestCommonType.setTransID(transId.toString());
		}else{
			logger.error("Error invoking CTRIP - ORDER UPDATE notifier: Unable to create unique transaction ID: " +uniqueTenDigitID);
			throw new IllegalArgumentException("Error invoking CTRIP - ORDER UPDATE notifier: Unable to create unique transaction ID: " +uniqueTenDigitID);
		}
		
		return requestCommonType;
	}

	protected boolean handleResponseCodes(String responseType, ResponseCommon resCom) {

		boolean success = resCom.getResCode().equals("000000");
		
		if (success) {
			logger.info("Successful response from CTRIP for Transaction ID: "+ resCom.getTransID());
		} else {
			logger.error("Error from CTRIP service: " +responseType + " [ Transaction ID: "+resCom.getTransID() + " , Response Code: " + resCom.getResCode()
					+ " , Response Description: " + resCom.getResDes() + " , Response Time: " + resCom.getRspTime() + " ]");
		}
		return success;
	}

	@Override
	public Object[] getObjectsEmail(String xml) {

		logger.debug("getObjectsEmail [" + xml + "]");

	//	String requestType = findRequestType(xml);

		EventMessageHelper helper = new EventMessageHelper();
		EventMessage message = helper.parseMessage(xml);

		Object[] obj = new Object[1];

		if(message!= null && (message.getOrderUpdateEventMessage() != null) ){
		//if (requestType.equals(UPDATE_ORDER)) {
			OrderUpdateEventMessage orderMessage = message
					.getOrderUpdateEventMessage();
			obj[0] = buildOrderUpdateEmail(orderMessage);
			
		}

		return obj;
	}

	/**
	 * CTRIP event xml consists of 2 requests- OrderUpdate/RatesUpdate. This
	 * method is used to find either type of request that needs to be created.
	 * 
	 * @param input
	 *            event xml
	 * @return requestType
	 */
	public String findRequestType(String xml) {

		DocumentBuilder builder;
		String requestType = null;
		try {
			builder = DocumentBuilderFactory.newInstance().newDocumentBuilder();
			InputSource input = new InputSource();
			input.setCharacterStream(new StringReader(xml));
			Document document;
			document = builder.parse(input);

			if (document.getElementsByTagName(UPDATE_ORDER).getLength() > 0) {
				requestType = UPDATE_ORDER;
			} else if (document.getElementsByTagName(UPDATE_RATES).getLength() > 0) {
				requestType = UPDATE_RATES;
			}else{
				logger.error("Error invoking CTRIP notifier: Unable to find the request type ( Order update/ Rates update).");
				throw new IllegalArgumentException("Error invoking CTRIP notifier: Unable to find the request type ( Order update/ Rates update).");
			}

		} catch (ParserConfigurationException e) {
			logger.error("Error parsing input xml [" + xml + " ]", e);
		} catch (SAXException e) {
			logger.error("Error parsing input xml [" + xml + " ]", e);
		} catch (IOException e) {
			logger.error("Error  parsing input xml", e);
		}

		return requestType;
	}

	private void initializeMapObjects() {
		status = new HashMap<String, String>();
		status.put("Q", "1");
		status.put("V", "2");
		status.put("P", "3");
		// Changes in CTRIP status - 22/03/2016
		//status.put("B", "4");
		status.put("K", "4");
		//status.put("X", "6");
		status.put("W", "5");
		status.put("N", "6");	
		
		statusDescription = new HashMap<String,String>();
		statusDescription.put("Q", "Quote");
		statusDescription.put("V", "Verified");
		statusDescription.put("P", "Processed");
		//statusDescription.put("B", "Received");
		statusDescription.put("K", "Picked Up");
		//statusDescription.put("X", "Cancelled");
		statusDescription.put("W", "Repurchased");
		statusDescription.put("N", "Returned");
		
		errorCodes = new HashMap<String,String>();

		errorCodes.put("E00001","Wrong supplier code");
		errorCodes.put("E00002","Supplier verification failed");
		errorCodes.put("E00003","Repeated transaction number");
		errorCodes.put("E00004", "Massage signature vilification failed");
		errorCodes.put("B00001", "Ctrip transaction number does not exsit");
		errorCodes.put("B00002", "Order status code incorrect");
		errorCodes.put("B00003", "Currency code incorrect");
		errorCodes.put("B00004", "Branch code does not exist");
		errorCodes.put("B00005", "Brach stores incorrect");
		
	}
	
	private Object buildOrderUpdateEmail(OrderUpdateEventMessage orderMessage) {

		if(orderMessage == null){
			return "";
		}
		StringBuilder emailMessage = new StringBuilder();
		emailMessage.append("<p>OrderStatusSync service failed. Please check the logs for more information.</p>");
		emailMessage.append("<table>");
		emailMessage.append("<tr><td>Order Number: </td><td>"+ orderMessage.getOrderNo() + "</td></tr>");
		emailMessage.append("<tr><td>External Order Number: </td><td>"+ orderMessage.getExternalOrderNo() + "</td></tr>");
		emailMessage.append("<tr><td>Status: </td><td>"+ statusDescription.get(orderMessage.getStatus()) + "</td></tr>");
		emailMessage.append("</table>");
		return emailMessage.toString();
	}
	
	private boolean isValid(String parameter) {
		if(parameter != null && !parameter.equals("")){
			return true;
		}

		return false;
	}
	
	public void getProperties(){
		ctripSecurity = new Properties();
		try {
			ctripSecurity.load(new FileInputStream(DIR+"/ctripSecurity-orderupdate.properties"));
			logger.info("Ctrip Security Configuration has been loaded for ORDER UPDATE notifier");
			logger.info("Ctrip Security Configuration = " + ctripSecurity);
		} catch (IOException e) {
			logger.error("Error invoking CTRIP - ORDER UPDATE notifier: ",e);
		}
	}
}
