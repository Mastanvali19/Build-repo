package com.ctrip.soa.financialservices.forex.forexvendorservice.v1;

import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlElement;
import javax.xml.bind.annotation.XmlRootElement;
import javax.xml.bind.annotation.XmlType;

import com.ctrip.soa.financialservices.forex.forexvendorservice.types.v1.RequestCommon;


@XmlRootElement(name="OrderStatusSyncRequest", namespace="http://soa.ctrip.com/financialservices/Forex/ForexVendorService/v1")
@XmlAccessorType(XmlAccessType.FIELD)
@XmlType(name = "OrderStatusSyncRequest"
		,propOrder = {	"requestCommon",
				    	"ctripOrderId",
					    "vendorReferId",
					    "orderStatus"
		}
		,namespace=""
)
public class OrderStatusSyncRequest {

    @XmlElement( required = true
    			, name="RequestCommon"
    			,namespace="http://soa.ctrip.com/financialservices/Forex/ForexVendorService/types/v1")
    protected RequestCommon requestCommon;

    @XmlElement( required = true,namespace="http://soa.ctrip.com/financialservices/Forex/ForexVendorService/v1")
    protected String ctripOrderId;
    
    @XmlElement(required = true,namespace="http://soa.ctrip.com/financialservices/Forex/ForexVendorService/v1")
    protected String vendorReferId;
    
    @XmlElement(namespace="http://soa.ctrip.com/financialservices/Forex/ForexVendorService/v1")
    protected short orderStatus;

    /**
     * Gets the value of the requestCommon property.
     * 
     * @return
     *     possible object is
     *     {@link RequestCommon }
     *     
     */
    public RequestCommon getRequestCommon() {
        return requestCommon;
    }

    /**
     * Sets the value of the requestCommon property.
     * 
     * @param value
     *     allowed object is
     *     {@link RequestCommon }
     *     
     */
    public void setRequestCommon(RequestCommon value) {
        this.requestCommon = value;
    }

    /**
     * Gets the value of the ctripOrderId property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getCtripOrderId() {
        return ctripOrderId;
    }

    /**
     * Sets the value of the ctripOrderId property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setCtripOrderId(String value) {
        this.ctripOrderId = value;
    }

    /**
     * Gets the value of the vendorReferId property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getVendorReferId() {
        return vendorReferId;
    }

    /**
     * Sets the value of the vendorReferId property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setVendorReferId(String value) {
        this.vendorReferId = value;
    }

    /**
     * Gets the value of the orderStatus property.
     * 
     */
    public short getOrderStatus() {
        return orderStatus;
    }

    /**
     * Sets the value of the orderStatus property.
     * 
     */
    public void setOrderStatus(short value) {
        this.orderStatus = value;
    }

}
