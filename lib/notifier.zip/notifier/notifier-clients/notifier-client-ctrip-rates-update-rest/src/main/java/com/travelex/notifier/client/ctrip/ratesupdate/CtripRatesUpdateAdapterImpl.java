package com.travelex.notifier.client.ctrip.ratesupdate;

import java.io.FileInputStream;
import java.io.IOException;
import java.io.StringReader;
import java.io.StringWriter;
import java.math.BigDecimal;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.Properties;

import javax.xml.bind.JAXBContext;
import javax.xml.bind.JAXBException;
import javax.xml.bind.Marshaller;
import javax.xml.parsers.DocumentBuilder;
import javax.xml.parsers.DocumentBuilderFactory;
import javax.xml.parsers.ParserConfigurationException;

import org.apache.cxf.interceptor.LoggingInInterceptor;
import org.apache.cxf.interceptor.LoggingOutInterceptor;
import org.apache.cxf.jaxrs.client.ClientConfiguration;
import org.apache.cxf.jaxrs.client.WebClient;
import org.apache.log4j.Logger;
import org.springframework.context.ApplicationContext;
import org.springframework.context.support.ClassPathXmlApplicationContext;
import org.w3c.dom.Document;
import org.xml.sax.InputSource;
import org.xml.sax.SAXException;

import com.ctrip.soa.financialservices.forex.forexvendorservice.v1.CurrencySyncInfoType;
import com.ctrip.soa.financialservices.forex.forexvendorservice.types.v1.RequestCommon;
import com.ctrip.soa.financialservices.forex.forexvendorservice.types.v1.ResponseCommon;
import com.ctrip.soa.financialservices.forex.forexvendorservice.v1.VendorCurrencyDataSyncRequest;
import com.ctrip.soa.financialservices.forex.forexvendorservice.v1.VendorCurrencyDataSyncResponse;
import com.travelex.notifier.adapter.ConnectorException;
import com.travelex.notifier.adapter.ServiceAdapter;
import com.travelex.notifier.adapter.ServiceAdapterCredentials;
import com.travelex.notifier.client.EventMessageHelper;
import com.travelex.notifier.client.conf.EventMessage;
import com.travelex.notifier.client.conf.RateType;
import com.travelex.notifier.client.conf.RatesUpdateEventMessage;
import com.travelex.notifier.client.ctrip.ratesupdate.util.CtripRatesUpdateHelper;

public class CtripRatesUpdateAdapterImpl extends ServiceAdapter {

	private static final Logger logger = Logger.getLogger(CtripRatesUpdateAdapterImpl.class);
	public static final String UPDATE_ORDER = "OrderUpdateEventMessage";
	public static final String UPDATE_RATES = "RatesUpdateEventMessage";
	private static final String TRANS_ORD = "ORD";
	private static final String TRANS_RTN = "RTN";
	private static final String CONSTANT_RATE = "999999.99";
	private static Properties  ctripSecurity;
	private static final String DIR = "/etc/notifier/ctrip";
	protected ApplicationContext context;
	
	protected Map<String, String> errorCodes;
	
	public CtripRatesUpdateAdapterImpl(ServiceAdapterCredentials credentials,ApplicationContext context) {
		super(credentials);

		if(context == null){
			context = new ClassPathXmlApplicationContext("classpath:applicationContext-ratesupdate.xml");
		}
		this.context = context;
		getProperties();
		initializeMapObjects();
		
	}

	@Override
	public boolean invoke(String xml) throws ConnectorException {
		
		logger.info("invoke xml:[" + xml + "]");
		//String requestType = findRequestType(xml);
		EventMessageHelper eventMessageHelper = new EventMessageHelper();
		EventMessage message = eventMessageHelper.parseMessage(xml);
		
		if(message!= null && message.getRatesUpdateEventMessage() != null){
			/*if (requestType.equals(UPDATE_ORDER)) {
				UpdateOrderEventMessage orderMessage = message
						.getOrderUpdateEventMessage();
				return invokeUpdateOrderService(orderMessage);
			} else if (requestType.equals(UPDATE_RATES)) {*/
				RatesUpdateEventMessage ratesMessage = message
						.getRatesUpdateEventMessage();
				return invokeRatesUpdateService(ratesMessage);
			//}
		}else{
			logger.error("Error invoking CTRIP - RATES UPDATE notifier: Invalid update rates request.");
			throw new IllegalArgumentException("Error invoking CTRIP - RATES UPDATE notifier: Invalid update rates request.");
		}
	}


	public boolean invokeRatesUpdateService(RatesUpdateEventMessage ratesMessage) {
		boolean success = false;
		VendorCurrencyDataSyncRequest vendorCurrencyRequest = buildRatesUpdateRequest(ratesMessage);
		logVendorCurrencyRequestPayload(vendorCurrencyRequest);
		try{
			if(vendorCurrencyRequest!= null && vendorCurrencyRequest.getList().size() > 0 && vendorCurrencyRequest.getRequestCommon()!= null){
				WebClient vendorService = createServiceClient();
				VendorCurrencyDataSyncResponse vendorCurrencyResponse = vendorService.post(vendorCurrencyRequest,VendorCurrencyDataSyncResponse.class);
		
				if (vendorCurrencyResponse != null
						&& vendorCurrencyResponse.getResponseCommon() != null) {
					success = handleResponseCodes("VendorCurrencyDataSyncResponse",vendorCurrencyResponse.getResponseCommon());
				}
			}
			
		}catch(Exception e){
			logger.error("Error invoking CTRIP - RATES UPDATE notifier: ",e);
		}
		return success;

	}

	private void logVendorCurrencyRequestPayload(
			VendorCurrencyDataSyncRequest vendorCurrencyRequest) {
		
		StringWriter writer = new StringWriter();
		JAXBContext context;
		try {
			context = JAXBContext.newInstance(VendorCurrencyDataSyncRequest.class);
			Marshaller m = context.createMarshaller();
			m.marshal(vendorCurrencyRequest, writer);
			logger.info("CTRIP VendorCurrencySync request payload: [ " + writer.toString() + "]");
		} catch (JAXBException e) {
			logger.error("Error marshalling Vendor currency sync request payload for logging.",e);
		}      
		
	}

	protected WebClient createServiceClient() {
		WebClient client = WebClient.create(credentials.getTargetEndpoint(), credentials.getUsername(), credentials.getPassword(), null);
		ClientConfiguration config = WebClient.getConfig(client);
		config.getInInterceptors().add(new LoggingInInterceptor());
		config.getOutInterceptors().add(new LoggingOutInterceptor());
		return client;
	}
	
	protected VendorCurrencyDataSyncRequest buildRatesUpdateRequest(RatesUpdateEventMessage ratesMessage) {
		
		VendorCurrencyDataSyncRequest vendorCurrencyRequest = new VendorCurrencyDataSyncRequest();
		if(ratesMessage.getRate().size() > 0){
			vendorCurrencyRequest.setRequestCommon(buildCommonRequest());
			mapRatesUpdateRequest(ratesMessage.getRate(),vendorCurrencyRequest);
			
		}else{
			logger.error("Error invoking CTRIP - RATES UPDATE notifier: No rates found. Please check the request XML from Foxweb.");
			throw new IllegalArgumentException("Error invoking CTRIP - RATES UPDATE notifier: No rates found. Please check the request XML from Foxweb.");
		}
		
		return vendorCurrencyRequest;
	}

	protected RequestCommon buildCommonRequest() {

		RequestCommon requestCommonType = new RequestCommon();

		Date date = new Date();
		SimpleDateFormat sdf = new SimpleDateFormat("yyyyMMddhhmmss");
		requestCommonType.setReqTime(sdf.format(date));

		CtripRatesUpdateHelper helper = new CtripRatesUpdateHelper();
		String uniqueTenDigitID = helper.getUniqueTransID(context);
		String vendorCode = ctripSecurity.getProperty("vendorCode");
		String vendorPassword = ctripSecurity.getProperty("vendorPassword");
		
		if(!(isValid(vendorCode) && isValid(vendorPassword))){
			logger.error("Error invoking CTRIP - RATES UPDATE notifier: Invalid security parameters in CTRIP configuration [ vendorCode: "+ vendorCode + " vendorPassword: "+vendorPassword + " ]");
			throw new IllegalArgumentException("Error invoking CTRIP - RATES UPDATE notifier: Invalid security parameters in CTRIP configuration.");
		}
		
		requestCommonType.setVendorCode(vendorCode);
		requestCommonType.setVendorPassword(vendorPassword);
		
		if(isValid(uniqueTenDigitID)){
			StringBuffer transId = new StringBuffer();
			SimpleDateFormat sdFormat = new SimpleDateFormat("yyyyMMdd");
			transId.append(vendorCode).append(sdFormat.format(date))
			.append(uniqueTenDigitID);
			requestCommonType.setTransID(transId.toString());
		}else{
			logger.error("Error invoking CTRIP - RATES UPDATE notifier: Unable to create unique transaction ID: " +uniqueTenDigitID);
			throw new IllegalArgumentException("Error invoking CTRIP - RATES UPDATE notifier: Unable to create unique transaction ID: " +uniqueTenDigitID);
		}
		
		return requestCommonType;
	}

	protected boolean handleResponseCodes(String responseType, ResponseCommon resCom) {

		boolean success = resCom.getResCode().equals("000000");
		
		if (success) {
			logger.info("Successful response from CTRIP for Transaction ID: "+ resCom.getTransID());
		} else {
			logger.error("Error from CTRIP service: " +responseType + " [ Transaction ID: "+resCom.getTransID() + " , Response Code: " + resCom.getResCode()
					+ " , Response Description: " + resCom.getResDes() + " , Response Time: " + resCom.getRspTime() + " ]");
		}
		return success;
	}

	@Override
	public Object[] getObjectsEmail(String xml) {

		logger.debug("getObjectsEmail [" + xml + "]");

		//String requestType = findRequestType(xml);

		EventMessageHelper helper = new EventMessageHelper();
		EventMessage message = helper.parseMessage(xml);

		Object[] obj = new Object[1];
		if(message!= null && message.getRatesUpdateEventMessage() != null){
		/*if (requestType.equals(UPDATE_ORDER)) {
			UpdateOrderEventMessage orderMessage = message
					.getOrderUpdateEventMessage();
			obj[0] = buildUpdateOrderEmail(orderMessage);
		} else if (requestType.equals(UPDATE_RATES)) {*/
			RatesUpdateEventMessage ratesMessage = message
					.getRatesUpdateEventMessage();
			obj[0] = buildRatesUpdateEmail(ratesMessage);
		}

		return obj;
	}

	/**
	 * CTRIP event xml consists of 2 requests- OrderUpdate/RatesUpdate. This
	 * method is used to find either type of request that needs to be created.
	 * 
	 * @param input
	 *            event xml
	 * @return requestType
	 */
	public String findRequestType(String xml) {

		DocumentBuilder builder;
		String requestType = null;
		try {
			builder = DocumentBuilderFactory.newInstance().newDocumentBuilder();
			InputSource input = new InputSource();
			input.setCharacterStream(new StringReader(xml));
			Document document;
			document = builder.parse(input);

			if (document.getElementsByTagName(UPDATE_ORDER).getLength() > 0) {
				requestType = UPDATE_ORDER;
			} else if (document.getElementsByTagName(UPDATE_RATES).getLength() > 0) {
				requestType = UPDATE_RATES;
			}else{
				logger.error("Error invoking CTRIP notifier: Unable to find the request type ( Order status/ Currency rates).");
				throw new IllegalArgumentException("Error invoking CTRIP notifier: Unable to find the request type ( Order status/ Currency rates).");
			}

		} catch (ParserConfigurationException e) {
			logger.error("Error parsing input xml [" + xml + " ]", e);
		} catch (SAXException e) {
			logger.error("Error parsing input xml [" + xml + " ]", e);
		} catch (IOException e) {
			logger.error("Error  parsing input xml", e);
		}

		return requestType;
	}

	private void initializeMapObjects() {
		
		errorCodes = new HashMap<String,String>();

		errorCodes.put("E00001","Wrong supplier code");
		errorCodes.put("E00002","Supplier verification failed");
		errorCodes.put("E00003","Repeated transaction number");
		errorCodes.put("E00004", "Massage signature vilification failed");
		errorCodes.put("B00001", "Ctrip transaction number does not exsit");
		errorCodes.put("B00002", "Order status code incorrect");
		errorCodes.put("B00003", "Currency code incorrect");
		errorCodes.put("B00004", "Branch code does not exist");
		errorCodes.put("B00005", "Brach stores incorrect");
		
	}
	
	public VendorCurrencyDataSyncRequest mapRatesUpdateRequest(List<RateType> ratesList, VendorCurrencyDataSyncRequest vendorCurrencyDataSyncRequest) {

		validateRates(ratesList);
			
		List<RateType> rateTypesToBeRemoved = new ArrayList<RateType>(); 
		
		for(int i=0; i<ratesList.size()-1; i++){
			int count = 0;
			for(int j=i+1 ; j<ratesList.size(); j++){
				/*if(isValid(ratesList.get(i).getEntityCode()) && isValid(ratesList.get(j).getEntityCode()) && 
						ratesList.get(i).getEntityCode().equals(ratesList.get(j).getEntityCode()) ){*/
				// If entities are equal, if valid entity or empty value for entity //e.g. when rates are pushed only for one entity, so only one condition
				if(ratesList.get(i).getEntityCode().equals(ratesList.get(j).getEntityCode()) && ratesList.get(i).getCurrencyCode().equals(ratesList.get(j).getCurrencyCode())){
						++count;
						if(count>=2){
							//rateTypesToBeRemoved.add(ratesList.get(j));
							logger.error("Error invoking CTRIP - RATES UPDATE notifier: Some entities have multiple or duplicate entries for the same currencies - "+ratesList.get(j).getEntityCode()+" ---- "+ratesList.get(j).getCurrencyCode() );
							//break;
						}
						CurrencySyncInfoType currencyType = new CurrencySyncInfoType();
						currencyType.setBranchCode(ratesList.get(j).getEntityCode());
						currencyType.setCurrencyCode(ratesList.get(j).getCurrencyCode());
						if(isValid(ratesList.get(i).getTransactionType())) {
							setRateByType(currencyType,ratesList.get(i).getTransactionType(),ratesList.get(i).getRate());
						}
						if(isValid(ratesList.get(j).getTransactionType())) {
							setRateByType(currencyType,ratesList.get(j).getTransactionType(),ratesList.get(j).getRate());
						}
						if(currencyType.getBuyRate()== null){
							currencyType.setBuyRate(new BigDecimal(CONSTANT_RATE));
						}
						if(currencyType.getSellRate() == null){
							currencyType.setSellRate(new BigDecimal(CONSTANT_RATE));
						}
						currencyType.setVendorCode(ctripSecurity.getProperty("vendorCode"));
						vendorCurrencyDataSyncRequest.getList().add(currencyType);
						rateTypesToBeRemoved.add(ratesList.get(i));
						rateTypesToBeRemoved.add(ratesList.get(j));
				}	
			}
		}
		
		ratesList.removeAll(rateTypesToBeRemoved);
		
		for(RateType rate: ratesList){
			CurrencySyncInfoType currencyType = new CurrencySyncInfoType();
			currencyType.setBranchCode(rate.getEntityCode());
			currencyType.setCurrencyCode((rate).getCurrencyCode());
			if(isValid(rate.getTransactionType()) && rate.getTransactionType().equalsIgnoreCase(TRANS_ORD)){
				currencyType.setSellRate(rate.getRate());
				currencyType.setBuyRate(new BigDecimal(CONSTANT_RATE));
			}else if(isValid(rate.getTransactionType()) && rate.getTransactionType().equalsIgnoreCase(TRANS_RTN)){
				currencyType.setSellRate(new BigDecimal(CONSTANT_RATE));
				currencyType.setBuyRate(rate.getRate());
			}else{
				currencyType.setSellRate(new BigDecimal(CONSTANT_RATE));
				currencyType.setBuyRate(new BigDecimal(CONSTANT_RATE));
			}
			currencyType.setVendorCode(ctripSecurity.getProperty("vendorCode"));
			vendorCurrencyDataSyncRequest.getList().add(currencyType);
		}
		
		validVendorCurrencyRequest(vendorCurrencyDataSyncRequest.getList());

		return vendorCurrencyDataSyncRequest;
	}

	private void setRateByType(CurrencySyncInfoType currencyType, String transactionType, BigDecimal rate) {
		if(transactionType.equalsIgnoreCase(TRANS_ORD)){
			currencyType.setSellRate(rate);
		}else if(transactionType.equalsIgnoreCase(TRANS_RTN)){
			currencyType.setBuyRate(rate);
		}
		
	}

	private void validVendorCurrencyRequest(List<CurrencySyncInfoType> currencySyncList) {
		boolean invalid = true;
		for(CurrencySyncInfoType curr:currencySyncList){
			if(!(isValid(curr.getVendorCode()) && isValid(curr.getBranchCode()) && isValid(curr.getCurrencyCode()) && curr.getSellRate()!=null && curr.getBuyRate()!=null)){
				logger.error(" Vendor code: "+ curr.getVendorCode() +" , Entity code : " + curr.getBranchCode() + " , Currency code : " + curr.getCurrencyCode() + " , Sell Rate : " + curr.getSellRate() + " , Buy Rate :" + curr.getBuyRate());
				invalid = false;
				break;
			}
		}
		
		if(!invalid){
			logger.error("Error invoking CTRIP - RATES UPDATE notifier: Invalid rates request created due to some missing mandatory fields.");
			throw new IllegalArgumentException("Error invoking CTRIP - RATES UPDATE notifier: Invalid rates request created due to some missing mandatory fields.");
		}
	}

	private void validateRates(List<RateType> ratesList) {

		boolean invalid = true;
		for(RateType rate:ratesList){
			if(!(isValid(rate.getEntityCode()) && isValid(rate.getCurrencyCode()) && rate.getRate()!= null)){
				invalid = false;
				break;
			}
		}
		if(!invalid){
			logger.error("Error invoking CTRIP - RATES UPDATE notifier: Invalid or empty values in Rates request. Please check the request XML from Foxweb.");
			throw new IllegalArgumentException("Error invoking CTRIP - RATES UPDATE notifier: Invalid or empty values in update rates request. Please check the request XML from Foxweb.");
		}
		
	}

	private Object buildRatesUpdateEmail(RatesUpdateEventMessage ratesMessage) {
		if(ratesMessage == null){
			return "";
		}
		StringBuilder emailMessage = new StringBuilder();
		emailMessage.append("<p>VendorCurrencyDataSync service failed. Please check the logs for more information.</p>");
		return emailMessage.toString();
	}

	
	private boolean isValid(String parameter) {
		if(parameter != null && !parameter.equals("")){
			return true;
		}

		return false;
	}
	
	public void getProperties(){
		ctripSecurity = new Properties();
		try {
			ctripSecurity.load(new FileInputStream(DIR+"/ctripSecurity-ratesupdate.properties"));
			logger.info("Ctrip Security Configuration has been loaded for RATES UPDATE notifier");
			logger.info("Ctrip Security Configuration = " + ctripSecurity);
		} catch (IOException e) {
			logger.error("Error invoking CTRIP - RATES UPDATE notifier: ",e);
		}
	}
}
