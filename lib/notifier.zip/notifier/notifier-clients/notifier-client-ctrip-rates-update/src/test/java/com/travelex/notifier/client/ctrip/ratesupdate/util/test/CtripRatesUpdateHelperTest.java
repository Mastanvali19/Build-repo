package com.travelex.notifier.client.ctrip.ratesupdate.util.test;

import static org.junit.Assert.assertEquals;

import org.junit.AfterClass;
import org.junit.BeforeClass;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.mockito.runners.MockitoJUnitRunner;
import org.springframework.context.ApplicationContext;
import org.springframework.context.support.ClassPathXmlApplicationContext;

import com.travelex.notifier.client.ctrip.ratesupdate.dao.CtripRatesUpdateDaoImpl;
import com.travelex.notifier.client.ctrip.ratesupdate.util.CtripRatesUpdateHelper;

@RunWith(MockitoJUnitRunner.class)
public class CtripRatesUpdateHelperTest {

	private static CtripRatesUpdateHelper helper;
	private static ApplicationContext context;
	
	@BeforeClass
	public static void setup(){
		context = new ClassPathXmlApplicationContext("classpath:test-applicationContext.xml");
		helper = new CtripRatesUpdateHelper();
		
	}
	
	@Test
	public void testGetUniqueTransID(){
		assertEquals(helper.getUniqueTransID(context),"0000000001");
		
	}
	
	@Test
	public void testProcessTransID(){
		assertEquals(helper.processTransactionId("ABC"),"0000000ABC");
		assertEquals(helper.processTransactionId("12"), "0000000012");
	}
	
	//@Test(expected=Exception.class)
	public void processTransIdThrowsException(){
		helper.processTransactionId(null);
	}
	
	@AfterClass
	public static void tearDown(){
		CtripRatesUpdateDaoImpl dao = (CtripRatesUpdateDaoImpl) context.getBean("ctripRatesUpdateDao");
		dao.getJdbcTemplate().execute("DROP TABLE TABLE_IDS");
		context = null;
		helper = null;
	}
}
