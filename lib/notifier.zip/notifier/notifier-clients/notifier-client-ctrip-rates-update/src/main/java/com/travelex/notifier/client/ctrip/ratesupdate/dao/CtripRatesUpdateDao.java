package com.travelex.notifier.client.ctrip.ratesupdate.dao;


public interface CtripRatesUpdateDao {

	public String getUniqueTransId();
}
