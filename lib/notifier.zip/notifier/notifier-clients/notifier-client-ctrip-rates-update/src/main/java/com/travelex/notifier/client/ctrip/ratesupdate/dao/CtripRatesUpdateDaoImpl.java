package com.travelex.notifier.client.ctrip.ratesupdate.dao;

import java.math.BigDecimal;

import org.apache.log4j.Logger;

public class CtripRatesUpdateDaoImpl extends BaseDao implements CtripRatesUpdateDao{

	private static final Logger logger = Logger.getLogger(CtripRatesUpdateDaoImpl.class);
	
	private static final String UPDATE_TRANS_ID = "UPDATE table_ids SET table_id = table_id + 1 WHERE table_name like 'CTRIPWS'";
	private static final String RESET_TRANS_ID = "UPDATE table_ids SET table_id = 1 WHERE table_name like 'CTRIPWS'";
	private static final String RETRIEVE_TRANS_ID = "SELECT TOP 1 table_id FROM table_ids WHERE table_name like 'CTRIPWS'";
	
	private final BigDecimal max = new BigDecimal("9999999999"); 

	@Override
	public String getUniqueTransId() {
		
		try{
				BigDecimal transId = getJdbcTemplate().queryForObject(RETRIEVE_TRANS_ID, BigDecimal.class);
				
				if(transId.compareTo(new BigDecimal(0))==0 || (transId.compareTo(max)==0) || (transId.compareTo(max)==1)){
					getJdbcTemplate().update(RESET_TRANS_ID);
				}else{
					getJdbcTemplate().update(UPDATE_TRANS_ID);
				}
				transId = getJdbcTemplate().queryForObject(RETRIEVE_TRANS_ID, BigDecimal.class);
				
				return transId.toString();
		
			}catch(Exception e){
				logger.error("Error invoking CTRIP - UPDATE RATES notifier: ",e);
			}
			
		return null;
	}

}
