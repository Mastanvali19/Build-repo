package com.travelex.notifier.client.ctrip.ratesupdate.dao;

import javax.sql.DataSource;

import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.transaction.PlatformTransactionManager;

public class BaseDao {

	protected JdbcTemplate jdbcTemplate;
	/*protected SimpleJdbcInsert simpleJdbcInsert;*/
	protected PlatformTransactionManager transactionManger;
	
	public JdbcTemplate getJdbcTemplate() {
		return jdbcTemplate;
	}
	public void setJdbcTemplate(JdbcTemplate jdbcTemplate) {
		this.jdbcTemplate = jdbcTemplate;
	}
	
	public void setDataSource(DataSource ds){
		this.jdbcTemplate = new JdbcTemplate(ds);
		/*this.simpleJdbcInsert = new SimpleJdbcInsert(jdbcTemplate).withTableName("table_ids").
				usingColumns("table_id").usingGeneratedKeyColumns("table_id");*/
	}
	
	public void setTransactionManager(PlatformTransactionManager transactionManger){
		this.transactionManger = transactionManger;
	}
	
}
