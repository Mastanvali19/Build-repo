package com.travelex.notifier.client.ctrip.ratesupdate.util;

import org.apache.log4j.Logger;
import org.springframework.context.ApplicationContext;

import com.travelex.notifier.client.ctrip.ratesupdate.dao.CtripRatesUpdateDaoImpl;

public class CtripRatesUpdateHelper {
	
	private static final Logger logger = Logger.getLogger(CtripRatesUpdateHelper.class);
	
	protected CtripRatesUpdateDaoImpl ctripRatesUpdateDao;
	
	public String getUniqueTransID(ApplicationContext context){
		
		String transId = null;
		try{
			if(context != null){
				ctripRatesUpdateDao = (CtripRatesUpdateDaoImpl) context.getBean("ctripRatesUpdateDao");	
				transId = ctripRatesUpdateDao.getUniqueTransId();
			}else{
				logger.debug("Error invoking CTRIP - UPDATE RATES notifier: Spring context not available");
				throw new IllegalArgumentException(" Technical or configuration issue -  Spring context not available. Please investigate further.");
			}
			
		}catch(Exception e){
			logger.debug("Error invoking CTRIP - UPDATE RATES notifier: Issue in either getting CTrip dao from context or database properties not set correctly or unavailable.");
			logger.error("Error invoking CTRIP - UPDATE RATES notifier: ",e);
		}
		
		return processTransactionId(transId);
	}

	public String processTransactionId(String transId) {
		
		if(transId == null){
			logger.error("Error invoking CTRIP - UPDATE RATES notifier: No Transaction ID returned from the database.");
			throw new IllegalArgumentException("Error invoking CTRIP - UPDATE RATES notifier: No Transaction ID returned from the database. ");
		}
		StringBuffer transStr = new StringBuffer();
		int transIdLength = transId.length();
		
		if(transIdLength<10){
			int remainingLength = 10 - transIdLength;
			for(int i=1; i<=remainingLength; i++){
				transStr = transStr.append("0");
			}
			transStr = transStr.append(transId);
		}
		
		return transStr.toString();
	}

}
