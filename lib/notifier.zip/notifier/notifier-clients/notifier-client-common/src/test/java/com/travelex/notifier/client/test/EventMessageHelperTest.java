package com.travelex.notifier.client.test;

import static org.junit.Assert.assertEquals;
import static org.junit.Assert.assertNotNull;
import static org.junit.Assert.assertNull;
import static org.mockito.Matchers.anyString;
import static org.mockito.Mockito.doThrow;
import static org.mockito.Mockito.when;

import java.io.StringReader;
import java.io.StringWriter;
import java.math.BigDecimal;
import java.util.ArrayList;
import java.util.List;

import javax.xml.bind.JAXBContext;
import javax.xml.bind.JAXBException;
import javax.xml.bind.Marshaller;
import javax.xml.bind.Unmarshaller;

import org.junit.After;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.Mockito;
import org.mockito.runners.MockitoJUnitRunner;
import org.xml.sax.SAXException;

import com.travelex.notifier.client.EventMessageHelper;
import com.travelex.notifier.client.conf.EventMessage;
import com.travelex.notifier.client.conf.OrderUpdateEventMessage;
import com.travelex.notifier.client.conf.RateType;

@RunWith(MockitoJUnitRunner.class)
public class EventMessageHelperTest {

	@Mock
	EventMessage eventMessage;
	@Mock
	OrderUpdateEventMessage orderEventMessage;
	@Mock
	StringWriter stringWriter;
	@Mock
	Marshaller marshal;
	
	@InjectMocks
	EventMessageHelper eventMessageHelper = new EventMessageHelper();
	
	private static final String xml = "<?xml version=\"1.0\" encoding=\"UTF-8\" standalone=\"yes\"?><EventMessage xmlns=\"http://travelex.org/foxweb/\"><OrderUpdateEventMessage><action>procTrans</action><orderId>1</orderId><orderNo>1</orderNo><externalOrderNo>1</externalOrderNo><status>P</status><customerName>ABC</customerName></OrderUpdateEventMessage></EventMessage>";

	@Test
	public void testParseXML() throws SAXException, JAXBException{
		
		Unmarshaller um = Mockito.mock(Unmarshaller.class);
		when(um.unmarshal(new StringReader(anyString()))).thenReturn(null);

		EventMessage msg = eventMessageHelper.parseMessage(xml);
		assertNotNull(msg);
		
		assertEquals(msg.getOrderUpdateEventMessage().getCustomerName(), "ABC");
		assertNull(msg.getRatesUpdateEventMessage());
	}
	
	@Test
	public void testBuildMessageForOrder() throws JAXBException{
		
		JAXBContext jc = Mockito.mock(JAXBContext.class);
		assertEquals(eventMessageHelper.buildMessage("procTrans", "1", "1", "1", "P", "ABC",null),xml);
		doThrow(new RuntimeException()).when(marshal).marshal(getEventMessage(),stringWriter);
	}
		
	@Test
	public void testBuildMessageForRates() throws JAXBException{
		List<RateType> ratesList = new ArrayList<RateType>();
		RateType rate = getRate();
		ratesList.add(rate);
		
		assertNotNull(eventMessageHelper.buildMessage(ratesList));
		doThrow(new RuntimeException()).when(marshal).marshal(eventMessage,stringWriter);
		
	}

	private EventMessage getEventMessage() {
		EventMessage msg = new EventMessage();
		OrderUpdateEventMessage eventMessage = new OrderUpdateEventMessage();
		eventMessage.setAction("procTrans");
		eventMessage.setOrderId("1");
		eventMessage.setOrderNo("1");
		eventMessage.setExternalOrderNo("1");
		eventMessage.setStatus("P");
		eventMessage.setCustomerName("ABC");
	    msg.setOrderUpdateEventMessage(eventMessage);
		return msg;
	}

	private RateType getRate() {
		RateType rate = new RateType();
		rate.setCurrencyCode("USD");
		rate.setEntityCode("199");
		rate.setTransactionType("ORD");
		rate.setRate(new BigDecimal(1.99));
		return rate;
	}

	@After
	public void tearDown(){
		eventMessageHelper = null;
	}
	
	
}
