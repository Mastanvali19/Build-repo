package com.travelex.notifier.client;

import java.io.StringReader;
import java.io.StringWriter;
import java.util.List;

import javax.xml.bind.JAXBContext;
import javax.xml.bind.Marshaller;
import javax.xml.bind.Unmarshaller;
import javax.xml.datatype.XMLGregorianCalendar;
import javax.xml.validation.Schema;
import javax.xml.validation.SchemaFactory;

import org.apache.log4j.Logger;

import com.travelex.notifier.client.conf.EventMessage;
import com.travelex.notifier.client.conf.OrderUpdateEventMessage;
import com.travelex.notifier.client.conf.RateType;
import com.travelex.notifier.client.conf.RatesUpdateEventMessage;

public class EventMessageHelper {

	private static final Logger logger = Logger.getLogger(EventMessageHelper.class);
	
	protected static final String CONF_CONTEXT_PATH = "com.travelex.notifier.client.conf";
	protected static final String SCHEMA_URL = "http://www.w3.org/2001/XMLSchema";
	
	public EventMessage parseMessage(String eventXml){
		EventMessage message = null;
		try {
			JAXBContext jc = JAXBContext.newInstance(CONF_CONTEXT_PATH);
			Unmarshaller um = jc.createUnmarshaller();
			SchemaFactory schemaFactory = SchemaFactory.newInstance(SCHEMA_URL);
			Schema schema = schemaFactory.newSchema(EventMessageHelper.class.getClassLoader().getResource("EventMessage.xsd"));
			um.setSchema(schema);

			message = (EventMessage) um.unmarshal(new StringReader(eventXml));

		} catch (Exception e){
			logger.error("Error parsing eventXML [" + eventXml + "]",e);
		}
		
		return message;		
	}	
	
	public String buildMessage(String action, String orderId, String orderNo, String externalOrderNo, String status, String customerName, XMLGregorianCalendar updateDateTime){	
		String returnMessage = null;
		
		EventMessage msg = new EventMessage();
		OrderUpdateEventMessage orderUpdateEventMessage = new OrderUpdateEventMessage();
		orderUpdateEventMessage.setAction(action);
		orderUpdateEventMessage.setOrderId(orderId);
		orderUpdateEventMessage.setOrderNo(orderNo);
		orderUpdateEventMessage.setExternalOrderNo(externalOrderNo);
		orderUpdateEventMessage.setStatus(status);
	    orderUpdateEventMessage.setCustomerName(customerName);
	    orderUpdateEventMessage.setUpdateDateTime(updateDateTime);
	    msg.setOrderUpdateEventMessage(orderUpdateEventMessage);
	    
		try {
			JAXBContext jc = JAXBContext.newInstance(CONF_CONTEXT_PATH);
			Marshaller m = jc.createMarshaller();
			
			SchemaFactory schemaFactory = SchemaFactory.newInstance(SCHEMA_URL);
			Schema schema = schemaFactory.newSchema(EventMessageHelper.class.getClassLoader().getResource("EventMessage.xsd"));
			m.setSchema(schema);

			StringWriter sr = new StringWriter();
			m.marshal(msg, sr);
			returnMessage = sr.getBuffer().toString();
			
		} catch (Exception e){
			logger.error("Error marshalling event message",e);
		}

		return returnMessage;
	}
	
	public String buildMessage(List<RateType> rates){
		String returnMessage = null;
		
		EventMessage msg = new EventMessage();
		RatesUpdateEventMessage  ratesUpdateEventMessage = new RatesUpdateEventMessage();
		if(rates.size()>0){
		    for(RateType rateType : rates){
		    	ratesUpdateEventMessage.getRate().add(rateType);
		    }
		}
	    msg.setRatesUpdateEventMessage(ratesUpdateEventMessage);
	    
		try {
			JAXBContext jc = JAXBContext.newInstance(CONF_CONTEXT_PATH);
			Marshaller m = jc.createMarshaller();
			
			SchemaFactory schemaFactory = SchemaFactory.newInstance(SCHEMA_URL);
			Schema schema = schemaFactory.newSchema(EventMessageHelper.class.getClassLoader().getResource("EventMessage.xsd"));
			m.setSchema(schema);

			StringWriter sr = new StringWriter();
			
			m.marshal(msg, sr);
			returnMessage = sr.getBuffer().toString();
			
		} catch (Exception e){
			logger.error("Error marshalling event message",e);
		}

		return returnMessage;
	}
}
