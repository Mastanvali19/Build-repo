package com.travelex.notifier.client;

public interface NotifierClientConstants {

	public static final String SALT_ORDERUPDATE_CLIENT="SALT_ORDERUPDATE"; 
	public static final String CTRIP_ORDERUPDATE_CLIENT = "CTRIP_ORDERUPDATE";
	public static final String CTRIP_RATESUPDATE_CLIENT = "CTRIP_RATESUPDATE";
	
}
