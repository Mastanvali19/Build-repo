package com.travelex.notifier.client.salt;

import com.travelex.notifier.adapter.ConnectorException;
import com.travelex.notifier.adapter.ServiceAdapter;
import com.travelex.notifier.adapter.ServiceAdapterCredentials;
import com.travelex.notifier.adapter.ServiceAdapterFactory;

public class SaltAdapterFactory implements ServiceAdapterFactory {

    public ServiceAdapter getAdapter(ServiceAdapterCredentials credentials) throws ConnectorException {
        return new SaltAdapterImpl(credentials);
    }
    
}