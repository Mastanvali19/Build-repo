package com.travelex.notifier.client.salt;

import java.io.FileInputStream;
import java.io.IOException;
import java.util.Properties;

import javax.security.auth.callback.Callback;
import javax.security.auth.callback.CallbackHandler;
import javax.security.auth.callback.UnsupportedCallbackException;

import org.apache.ws.security.WSPasswordCallback;

public class SaltPasswordHandler implements CallbackHandler {

	private static final String DIR = "/etc/notifier/salt/";

	public void handle(Callback[] callbacks) throws IOException, UnsupportedCallbackException {

		Properties prop = new Properties();
		prop.load(new FileInputStream(DIR+ "notifier-salt-credentials.properties"));
		for (int i = 0; i < callbacks.length; i++) {
			// When the server side need to authenticate the user
			WSPasswordCallback pwcb = (WSPasswordCallback) callbacks[i];
			String password = prop.getProperty(pwcb.getIdentifier());
			if (password != null) {
				pwcb.setPassword(password);
				return;
			}
		}
	}
}
