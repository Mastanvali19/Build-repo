package com.travelex.notifier.client.salt;

import java.util.HashMap;
import java.util.Map;

import javax.xml.namespace.QName;
import javax.xml.stream.XMLStreamException;

import org.apache.axiom.om.OMElement;
import org.apache.axiom.om.impl.builder.StAXOMBuilder;
import org.apache.axiom.om.util.AXIOMUtil;
import org.apache.axis2.addressing.EndpointReference;
import org.apache.axis2.client.Options;
import org.apache.axis2.client.ServiceClient;
import org.apache.axis2.context.ConfigurationContext;
import org.apache.axis2.context.ConfigurationContextFactory;
import org.apache.log4j.Logger;
import org.apache.neethi.Policy;
import org.apache.neethi.PolicyEngine;
import org.apache.rampart.RampartMessageData;

import com.travelex.notifier.adapter.ConnectorException;
import com.travelex.notifier.adapter.ServiceAdapter;
import com.travelex.notifier.adapter.ServiceAdapterCredentials;
import com.travelex.notifier.client.EventMessageHelper;
import com.travelex.notifier.client.conf.EventMessage;
import com.travelex.notifier.client.conf.OrderUpdateEventMessage;

public class SaltAdapterImpl extends ServiceAdapter {

	private static final Logger logger = Logger.getLogger(SaltAdapterImpl.class);
	
	protected Map<String,String> status;
	protected Map<String,String> statusDescription;	
	
	private static final String DIR = "/etc/notifier/salt/security";
	
	public SaltAdapterImpl(ServiceAdapterCredentials credentials) {
		super(credentials);
		
		status = new HashMap<String,String>();
		status.put("procTrans", "C");
		status.put("cancel", "CN");
		status.put("P", "C");
		status.put("X", "CN");
		status.put("Processed", "C");
		status.put("Cancelled","CN");
		
		//SALT status
		statusDescription = new HashMap<String,String>();
		statusDescription.put("CN", "Cancelled");
		statusDescription.put("C", "Complete");
		statusDescription.put("RC", "ReversalComplete");
		statusDescription.put("I", "Incomplete");
		statusDescription.put("PC", "Pending Complete");
	}
	
	public boolean invoke(String xml) throws ConnectorException {

		logger.info("invoke xml:[" + xml + "]");
		EventMessageHelper helper = new EventMessageHelper(); 
		
		EventMessage message = helper.parseMessage(xml);

		try {
			
			if(message != null && message.getOrderUpdateEventMessage()!= null){

				OrderUpdateEventMessage orderMessage = message.getOrderUpdateEventMessage();
				
				//Added validation for customerName & orderID as they were made mandatory for SALT order Update in EventMessage XSD.
				if(!(status.containsKey(orderMessage.getAction()) && isValid(orderMessage.getCustomerName()) && isValid(orderMessage.getOrderId()))){
					logger.error("Missing values in request: action<" + orderMessage.getAction() + "> , customerName<" + orderMessage.getCustomerName() + "> , orderId<" + orderMessage.getOrderId() + ">");
					return false;
				}
				
				ConfigurationContext ctx = ConfigurationContextFactory.createConfigurationContextFromFileSystem(DIR+"/rampart-1.6.2.mar",null);
				
				ServiceClient client = new ServiceClient(ctx, null);
		        Options options = new Options();
		        options.setAction("urn:Order#Update");
		        options.setTo(new EndpointReference(credentials.getTargetEndpoint()));
		        options.setProperty(RampartMessageData.KEY_RAMPART_POLICY,  loadPolicy("/policy.xml"));
		        client.setOptions(options);
		        
		        client.engageModule("rampart");
		        
		        OMElement response = client.sendReceive(getPayload(orderMessage.getExternalOrderNo(),orderMessage.getOrderNo(),status.get(orderMessage.getStatus())));
		        
		        logger.debug("SALT response: [" + response + "]");
		        
		        OMElement requestAccepted = response.getFirstChildWithName(new QName("", "RequestAccepted"));
		        
		        logger.info("SALT request accepted for Order No: "+ orderMessage.getOrderNo() +"[" + requestAccepted.getText() + "]");
		        
		        return requestAccepted.getText().equalsIgnoreCase("true");
		        
			}
			
		} catch (Exception e) {
			logger.error("Error invoking SALT: " + e.getMessage());
			e.printStackTrace();
		}

		return false;
	}

	@Override
	public Object[] getObjectsEmail(String xml) {
		logger.debug("getObjectsEmail [" + xml + "]");
		Object[] obj = new Object[3];
		EventMessageHelper helper = new EventMessageHelper(); 
		
		EventMessage message = helper.parseMessage(xml);
		OrderUpdateEventMessage orderMessage = message.getOrderUpdateEventMessage();
		obj[0] = orderMessage.getExternalOrderNo();
		obj[1] = statusDescription.get(status.get(orderMessage.getAction()));
		obj[2] = orderMessage.getCustomerName();
		return obj;
	}
	
    protected Policy loadPolicy(String xmlPath) throws Exception {
    	StAXOMBuilder builder = new StAXOMBuilder(DIR+xmlPath);
        return PolicyEngine.getPolicy(builder.getDocumentElement());
    }
    
    protected OMElement getPayload(String saltOrderId, String foxwebOrderNumber, String status) throws XMLStreamException {

    	StringBuffer payloadString = new StringBuffer();
		payloadString.append("<ns2:OrderUpdate xmlns:ns2=\"urn:SALTServices\">");				
		payloadString.append("<OrderUpdateItemList>");

		payloadString.append("<Order_ID>").append(saltOrderId).append("</Order_ID>");
		payloadString.append("<Order_InternalID>").append(foxwebOrderNumber).append("</Order_InternalID>");		
		payloadString.append("<Order_Status>").append(status).append("</Order_Status>");		
		
		payloadString.append("</OrderUpdateItemList>");		
		payloadString.append("</ns2:OrderUpdate>");

		logger.debug("payload [" + payloadString.toString() + "]");
		
		OMElement payload = AXIOMUtil.stringToOM(payloadString.toString());
		
        return payload;
    }	
	
    private boolean isValid(String parameter) {
		if(parameter != null && !parameter.equals("")){
			return true;
		}

		return false;
	}
}