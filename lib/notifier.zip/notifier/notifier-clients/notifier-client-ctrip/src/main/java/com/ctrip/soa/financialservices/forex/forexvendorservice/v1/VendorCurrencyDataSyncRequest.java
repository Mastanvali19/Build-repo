package com.ctrip.soa.financialservices.forex.forexvendorservice.v1;

import java.util.ArrayList;
import java.util.List;

import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlElement;
import javax.xml.bind.annotation.XmlRootElement;
import javax.xml.bind.annotation.XmlType;

import com.ctrip.soa.financialservices.forex.forexvendorservice.types.v1.CurrencySyncInfoType;
import com.ctrip.soa.financialservices.forex.forexvendorservice.types.v1.RequestCommon;

@XmlRootElement(name="VendorCurrencyDataSyncRequest", namespace="http://soa.ctrip.com/financialservices/Forex/ForexVendorService/v1")
@XmlAccessorType(XmlAccessType.FIELD)
@XmlType(name = "VendorCurrencyDataSyncRequest", propOrder = {
    "requestCommon",
    "list"
})
public class VendorCurrencyDataSyncRequest {

    @XmlElement(name="RequestCommon"
			   ,required=true 
			   ,namespace="http://soa.ctrip.com/financialservices/Forex/ForexVendorService/types/v1")
    protected RequestCommon requestCommon;
    
    @XmlElement(name = "List"
    		   ,required=true
    		   ,namespace="http://soa.ctrip.com/financialservices/Forex/ForexVendorService/types/v1")
    protected List<CurrencySyncInfoType> list;

    /**
     * Gets the value of the requestCommon property.
     * 
     * @return
     *     possible object is
     *     {@link RequestCommon }
     *     
     */
    public RequestCommon getRequestCommon() {
        return requestCommon;
    }

    /**
     * Sets the value of the requestCommon property.
     * 
     * @param value
     *     allowed object is
     *     {@link RequestCommon }
     *     
     */
    public void setRequestCommon(RequestCommon value) {
        this.requestCommon = value;
    }

    /**
     * Gets the value of the list property.
     * 
     * <p>
     * This accessor method returns a reference to the live list,
     * not a snapshot. Therefore any modification you make to the
     * returned list will be present inside the JAXB object.
     * This is why there is not a <CODE>set</CODE> method for the list property.
     * 
     * <p>
     * For example, to add a new item, do as follows:
     * <pre>
     *    getList().add(newItem);
     * </pre>
     * 
     * 
     * <p>
     * Objects of the following type(s) are allowed in the list
     * {@link CurrencySyncInfoType }
     * 
     * 
     */
    public List<CurrencySyncInfoType> getList() {
        if (list == null) {
            list = new ArrayList<CurrencySyncInfoType>();
        }
        return this.list;
    }

}
