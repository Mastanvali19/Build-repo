package com.ctrip.soa.financialservices.forex.forexvendorservice.types.v1;

import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlElement;
import javax.xml.bind.annotation.XmlType;

@XmlAccessorType(XmlAccessType.FIELD)
@XmlType(name = "ResponseCommon", propOrder = {
    "transID",
    "rspTime",
    "resCode",
    "resDes"
},namespace="http://soa.ctrip.com/financialservices/Forex/ForexVendorService/types/v1")
public class ResponseCommon {

    @XmlElement(name = "TransID", required = true)
    protected String transID;
    @XmlElement(name = "RspTime", required = true)
    protected String rspTime;
    @XmlElement(name = "ResCode", required = true)
    protected String resCode;
    @XmlElement(name = "ResDes", required = true)
    protected String resDes;

    /**
     * Gets the value of the transID property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getTransID() {
        return transID;
    }

    /**
     * Sets the value of the transID property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setTransID(String value) {
        this.transID = value;
    }

    /**
     * Gets the value of the rspTime property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getRspTime() {
        return rspTime;
    }

    /**
     * Sets the value of the rspTime property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setRspTime(String value) {
        this.rspTime = value;
    }

    /**
     * Gets the value of the resCode property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getResCode() {
        return resCode;
    }

    /**
     * Sets the value of the resCode property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setResCode(String value) {
        this.resCode = value;
    }

    /**
     * Gets the value of the resDes property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getResDes() {
        return resDes;
    }

    /**
     * Sets the value of the resDes property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setResDes(String value) {
        this.resDes = value;
    }

}
