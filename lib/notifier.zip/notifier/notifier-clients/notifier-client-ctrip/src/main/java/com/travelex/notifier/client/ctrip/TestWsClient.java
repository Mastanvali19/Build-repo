package com.travelex.notifier.client.ctrip;

import java.io.FileInputStream;
import java.io.IOException;
import java.io.StringReader;
import java.math.BigDecimal;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;
import java.util.Properties;

import javax.xml.bind.JAXBContext;
import javax.xml.bind.JAXBException;
import javax.xml.bind.Marshaller;
import javax.xml.bind.Unmarshaller;

import org.apache.cxf.interceptor.LoggingInInterceptor;
import org.apache.cxf.interceptor.LoggingOutInterceptor;
import org.apache.cxf.jaxrs.client.ClientConfiguration;
import org.apache.cxf.jaxrs.client.WebClient;

import com.ctrip.soa.financialservices.forex.forexvendorservice.types.v1.CurrencySyncInfoType;
import com.ctrip.soa.financialservices.forex.forexvendorservice.types.v1.RequestCommon;
import com.ctrip.soa.financialservices.forex.forexvendorservice.v1.OrderStatusSyncRequest;
import com.ctrip.soa.financialservices.forex.forexvendorservice.v1.OrderStatusSyncResponse;
import com.ctrip.soa.financialservices.forex.forexvendorservice.v1.VendorCurrencyDataSyncRequest;
import com.ctrip.soa.financialservices.forex.forexvendorservice.v1.VendorCurrencyDataSyncResponse;
import com.travelex.notifier.client.conf.RateType;
import com.travelex.notifier.client.ctrip.util.CtripRatesHelper;

public class TestWsClient {
	
	static Properties sec;
	
	public static void main(String[] args) {
		TestWsClient t = new TestWsClient();

		sec = new Properties();
		try {
			sec.load(new FileInputStream("/etc/notifier/ctrip/ctripSecurity.properties"));
		} catch (IOException e) {
			e.printStackTrace();
		}		
		
		try {
//			t.doTestOrderStatusSyncResponseJAXB();
//			t.doTestOrderStatusSyncJAXB();
//			t.doTestOrderStatusSync();
//			t.doTestVendorCurrencyDataSyncJAXB();
//			t.doTestVendorCurrencyDataSyncRequest();
			t.doTestVendorCurrencyDataSyncResponseJAXB();			
//			t.doTestRatesHelper();
		} catch (JAXBException e) {
			e.printStackTrace();
		}
	}

	protected void doTestOrderStatusSyncJAXB() throws JAXBException{
		JAXBContext jc = JAXBContext.newInstance(OrderStatusSyncRequest.class); 
		Marshaller m = jc.createMarshaller();
		m.setProperty(Marshaller.JAXB_FORMATTED_OUTPUT, true);
		m.marshal(buildOrderStatusRequest(), System.out);
	}

	protected void doTestOrderStatusSyncResponseJAXB() throws JAXBException{
		JAXBContext jc = JAXBContext.newInstance(OrderStatusSyncResponse.class); 
		Unmarshaller um = jc.createUnmarshaller();
		OrderStatusSyncResponse response = (OrderStatusSyncResponse)um.unmarshal(new StringReader(buildOrderStatusResponse()));
		
		System.out.println(response);
		
	}	
	
	protected void doTestVendorCurrencyDataSyncResponseJAXB() throws JAXBException{
		JAXBContext jc = JAXBContext.newInstance(VendorCurrencyDataSyncResponse.class); 
		Unmarshaller um = jc.createUnmarshaller();
		VendorCurrencyDataSyncResponse response = (VendorCurrencyDataSyncResponse)um.unmarshal(new StringReader(buildVendorCurrencyDataSyncResponse()));
		
		System.out.println(response);
		
	}	
	
	protected String buildOrderStatusResponse(){
		StringBuffer sb = new StringBuffer();
		
		sb.append("<?xml version=\"1.0\" encoding=\"UTF-8\"?><OrderStatusSyncResponse xmlns:xsd=\"http://www.w3.org/2001/XMLSchema\" xmlns:xsi=\"http://www.w3.org/2001/XMLSchema-instance\" xmlns=\"http://soa.ctrip.com/financialservices/Forex/ForexVendorService/v1\">");
		sb.append("<ResponseStatus xmlns=\"http://soa.ctrip.com/financialservices/Forex/ForexVendorService/types/v1\">");
		sb.append("<Timestamp xmlns=\"http://soa.ctrip.com/common/types/v1\">2016-05-30T06:31:40.3865624+08:00</Timestamp>");
		sb.append("<Ack xmlns=\"http://soa.ctrip.com/common/types/v1\">Success</Ack>");
		sb.append("<Extension xmlns=\"http://soa.ctrip.com/common/types/v1\">");
		sb.append("<Id>CLOGGING_TRACE_ID</Id>");
		sb.append("<Value>4344137637898436827</Value>");
		sb.append("</Extension>");
		sb.append("</ResponseStatus>");
		sb.append("<ResponseCommon xmlns=\"http://soa.ctrip.com/financialservices/Forex/ForexVendorService/types/v1\">");
		sb.append("<TransID>002201605300000004728</TransID>");
		sb.append("<RspTime>20160530063139</RspTime>");
		sb.append("<ResCode>9000010</ResCode>");
		sb.append("<ResDes>??????</ResDes>");
		sb.append("</ResponseCommon>");
		sb.append("</OrderStatusSyncResponse>");
		
		return sb.toString();
	}
	
	protected String buildVendorCurrencyDataSyncResponse(){
		StringBuffer sb = new StringBuffer();
		
		sb.append("<?xml version=\"1.0\" encoding=\"UTF-8\"?><VendorCurrencyDataSyncResponse xmlns:xsd=\"http://www.w3.org/2001/XMLSchema\" xmlns:xsi=\"http://www.w3.org/2001/XMLSchema-instance\" xmlns=\"http://soa.ctrip.com/financialservices/Forex/ForexVendorService/v1\">");
		sb.append("<ResponseStatus xmlns=\"http://soa.ctrip.com/financialservices/Forex/ForexVendorService/types/v1\">");
		sb.append("<Timestamp xmlns=\"http://soa.ctrip.com/common/types/v1\">2016-05-30T10:35:34.4075236+08:00</Timestamp>");
		sb.append("<Ack xmlns=\"http://soa.ctrip.com/common/types/v1\">Success</Ack>");
		sb.append("<Extension xmlns=\"http://soa.ctrip.com/common/types/v1\">");
		sb.append("<Id>CLOGGING_TRACE_ID</Id>");
		sb.append("<Value>6990964910216610203</Value>");
		sb.append("</Extension>");
		sb.append("</ResponseStatus>");
		sb.append("<ResponseCommon xmlns=\"http://soa.ctrip.com/financialservices/Forex/ForexVendorService/types/v1\">");
		sb.append("<TransID>002201605300000004737</TransID>");
		sb.append("<RspTime>20160530103534</RspTime>");
		sb.append("<ResCode>000000</ResCode>");
		sb.append("<ResDes>?????????</ResDes>");
		sb.append("</ResponseCommon>");
		sb.append("</VendorCurrencyDataSyncResponse>");
		
		return sb.toString();
	}
	
	protected void doTestVendorCurrencyDataSyncJAXB() throws JAXBException{
		JAXBContext jc = JAXBContext.newInstance(VendorCurrencyDataSyncRequest.class); 
		Marshaller m = jc.createMarshaller();
		m.setProperty(Marshaller.JAXB_FORMATTED_OUTPUT, true);
		m.marshal(buildVendorCurrencyDataSyncRequest(), System.out);
	}
	
	
	protected void doTestOrderStatusSync() throws JAXBException{
		WebClient client = WebClient.create("http://apiproxy.ctripqa.com/apiproxy/soa2/11517/xml/OrderStatusSync", "www.travelex.com", "travelex", null);
		
		ClientConfiguration config = WebClient.getConfig(client);
		
		config.getInInterceptors().add(new LoggingInInterceptor());
		config.getOutInterceptors().add(new LoggingOutInterceptor());
		
		OrderStatusSyncResponse response = client.post(buildOrderStatusRequest(),OrderStatusSyncResponse.class);

	}

	protected void doTestVendorCurrencyDataSyncRequest() throws JAXBException{
		WebClient client = WebClient.create("http://apiproxy.ctripqa.com/apiproxy/soa2/11517/xml/VendorCurrencyDataSync", "www.travelex.com", "travelex", null);

		ClientConfiguration config = WebClient.getConfig(client);
		
		config.getInInterceptors().add(new LoggingInInterceptor());
		config.getOutInterceptors().add(new LoggingOutInterceptor());

		VendorCurrencyDataSyncResponse response = client.post(buildVendorCurrencyDataSyncRequest(),VendorCurrencyDataSyncResponse.class);

	}
	
	
	protected OrderStatusSyncRequest buildOrderStatusRequest() {
		OrderStatusSyncRequest orderstatusRequest = new OrderStatusSyncRequest();

		RequestCommon requestCommonType = buildCommonRequest();

		orderstatusRequest.setRequestCommon(requestCommonType);
		orderstatusRequest.setCtripOrderId("300000092");
		orderstatusRequest.setOrderStatus(Short.parseShort("4"));
		orderstatusRequest.setVendorReferId("100526");

		return orderstatusRequest;
	}
	
	protected RequestCommon buildCommonRequest() {
		RequestCommon requestCommonType = new RequestCommon();
		Date date = new Date();
		 
		SimpleDateFormat sdf = new SimpleDateFormat("yyyyMMddHHmmss");
		requestCommonType.setReqTime(sdf.format(date));

		String uniqueTenDigitID = ("" + System.currentTimeMillis()).substring(0, 9);
		String userName = "002";
		String password = "ba3253876aed6bc22d4a6ff53d8406c6ad864195ed144ab5c87621b6c233b548baeae6956df346ec8c17f5ea10f35ee3cbc514797ed7ddd3145464e2a0bab413";

		requestCommonType.setVendorCode(userName);
		requestCommonType.setVendorPassword(password);
		
		StringBuffer transId = new StringBuffer();
		SimpleDateFormat sdFormat = new SimpleDateFormat("yyyyMMdd");
		transId.append(userName).append(sdFormat.format(date)).append(uniqueTenDigitID);
		requestCommonType.setTransID(transId.toString());
		
		return requestCommonType;
	}	
	
	protected VendorCurrencyDataSyncRequest buildVendorCurrencyDataSyncRequest() {
		VendorCurrencyDataSyncRequest request = new VendorCurrencyDataSyncRequest();

		RequestCommon requestCommonType = buildCommonRequest();

		request.setRequestCommon(requestCommonType);
		CurrencySyncInfoType c1 = new CurrencySyncInfoType();
		c1.setBranchCode("909923");
		c1.setCurrencyCode("AED");
		c1.setVendorCode("002");
		c1.setSellRate(new BigDecimal("183.2849"));
		c1.setBuyRate(new BigDecimal("173.6030"));
		request.getList().add(c1);

		return request;
	}	
	
	
	
	protected void doTestRatesHelper() throws JAXBException{
		CtripRatesHelper helper = new CtripRatesHelper();
		VendorCurrencyDataSyncRequest request = helper.prepareRates(buildRatesList(),sec);
		
		JAXBContext jc = JAXBContext.newInstance(VendorCurrencyDataSyncRequest.class); 
		Marshaller m = jc.createMarshaller();
		m.setProperty(Marshaller.JAXB_FORMATTED_OUTPUT, true);
		m.marshal(request, System.out);		
	}
		
	
	protected List<RateType> buildRatesList(){
		List<RateType> list = new ArrayList<RateType>();

		list.add(buildRateType("909908","ORD","CCN","AED","184.327500"));
		list.add(buildRateType("909908","RTN","CCN","AED","174.610400"));
		list.add(buildRateType("909908","ORD","CCN","AUD","477.547900"));
		list.add(buildRateType("909908","RTN","CCN","AUD","464.830300"));
		list.add(buildRateType("909908","ORD","CCN","CAD","508.948800"));
		list.add(buildRateType("909908","RTN","CCN","CAD","495.034800"));
		list.add(buildRateType("909908","ORD","CCN","CHF","668.509800"));
		list.add(buildRateType("909908","RTN","CCN","CHF","649.581300"));
		list.add(buildRateType("909908","ORD","CCN","DKK","100.042300"));
		list.add(buildRateType("909908","RTN","CCN","DKK","96.726200"));
		list.add(buildRateType("909908","ORD","CCN","EUR","738.924900"));
		list.add(buildRateType("909908","RTN","CCN","EUR","719.182500"));
		list.add(buildRateType("909908","ORD","CCN","GBP","968.862600"));
		list.add(buildRateType("909908","RTN","CCN","GBP","943.531500"));
		list.add(buildRateType("909908","ORD","CCN","HKD","84.914500"));
		list.add(buildRateType("909908","RTN","CCN","HKD","83.881200"));
		list.add(buildRateType("909908","ORD","CCN","IDR","0.050400"));
		list.add(buildRateType("909908","RTN","CCN","IDR","0.045500"));
		list.add(buildRateType("909908","ORD","CCN","INR","10.341200"));
		list.add(buildRateType("909908","RTN","CCN","INR","9.076800"));
		list.add(buildRateType("909908","ORD","CCN","JPY","6.013300"));
		list.add(buildRateType("909908","RTN","CCN","JPY","5.853900"));
		list.add(buildRateType("909908","ORD","CCN","KRW","0.576400"));
		list.add(buildRateType("909908","RTN","CCN","KRW","0.537500"));
		list.add(buildRateType("909908","ORD","CCN","MOP","83.040900"));
		list.add(buildRateType("909908","RTN","CCN","MOP","80.905600"));
		list.add(buildRateType("909908","ORD","CCN","MYR","165.049600"));
		list.add(buildRateType("909908","RTN","CCN","MYR","157.885900"));
		list.add(buildRateType("909908","ORD","CCN","NOK","80.301400"));
		list.add(buildRateType("909908","RTN","CCN","NOK","77.720500"));
		list.add(buildRateType("909908","ORD","CCN","NZD","447.673200"));
		list.add(buildRateType("909908","RTN","CCN","NZD","434.082700"));
		list.add(buildRateType("909908","ORD","CCN","PHP","14.711000"));
		list.add(buildRateType("909908","RTN","CCN","PHP","13.769000"));
		list.add(buildRateType("909908","ORD","CCN","SEK","80.240600"));
		list.add(buildRateType("909908","RTN","CCN","SEK","77.663500"));
		list.add(buildRateType("909908","ORD","CCN","SGD","481.395800"));
		list.add(buildRateType("909908","RTN","CCN","SGD","467.973000"));
		list.add(buildRateType("909908","ORD","CCN","THB","18.868600"));
		list.add(buildRateType("909908","RTN","CCN","THB","18.086600"));
		list.add(buildRateType("909908","ORD","CCN","TWD","21.028200"));
		list.add(buildRateType("909908","RTN","CCN","TWD","19.483800"));
		list.add(buildRateType("909908","ORD","CCN","USD","660.103000"));
		list.add(buildRateType("909908","RTN","CCN","USD","651.740000"));
		list.add(buildRateType("909908","ORD","CCN","VND","0.031500"));
		list.add(buildRateType("909908","RTN","CCN","VND","0.027800"));
		list.add(buildRateType("909915","ORD","CCN","AED","184.327500"));
		list.add(buildRateType("909915","RTN","CCN","AED","174.610400"));
		list.add(buildRateType("909915","ORD","CCN","AUD","477.547900"));
		list.add(buildRateType("909915","RTN","CCN","AUD","464.830300"));
		list.add(buildRateType("909915","ORD","CCN","CAD","508.948800"));
		list.add(buildRateType("909915","RTN","CCN","CAD","495.034800"));
		list.add(buildRateType("909915","ORD","CCN","CHF","668.509800"));
		list.add(buildRateType("909915","RTN","CCN","CHF","649.581300"));
		list.add(buildRateType("909915","ORD","CCN","DKK","100.042300"));
		list.add(buildRateType("909915","RTN","CCN","DKK","96.726200"));
		list.add(buildRateType("909915","ORD","CCN","EUR","738.924900"));
		list.add(buildRateType("909915","RTN","CCN","EUR","719.182500"));
		list.add(buildRateType("909915","ORD","CCN","GBP","968.862600"));
		list.add(buildRateType("909915","RTN","CCN","GBP","943.531500"));
		list.add(buildRateType("909915","ORD","CCN","HKD","84.914500"));
		list.add(buildRateType("909915","RTN","CCN","HKD","83.881200"));
		list.add(buildRateType("909915","ORD","CCN","IDR","0.050400"));
		list.add(buildRateType("909915","RTN","CCN","IDR","0.045500"));
		list.add(buildRateType("909915","ORD","CCN","INR","10.341200"));
		list.add(buildRateType("909915","RTN","CCN","INR","9.076800"));
		list.add(buildRateType("909915","ORD","CCN","JPY","6.013300"));
		list.add(buildRateType("909915","RTN","CCN","JPY","5.853900"));
		list.add(buildRateType("909915","ORD","CCN","KRW","0.576400"));
		list.add(buildRateType("909915","RTN","CCN","KRW","0.537500"));
		list.add(buildRateType("909915","ORD","CCN","MOP","83.040900"));
		list.add(buildRateType("909915","RTN","CCN","MOP","80.905600"));
		list.add(buildRateType("909915","ORD","CCN","MYR","165.049600"));
		list.add(buildRateType("909915","RTN","CCN","MYR","157.885900"));
		list.add(buildRateType("909915","ORD","CCN","NOK","80.301400"));
		list.add(buildRateType("909915","RTN","CCN","NOK","77.720500"));
		list.add(buildRateType("909915","ORD","CCN","NZD","447.673200"));
		list.add(buildRateType("909915","RTN","CCN","NZD","434.082700"));
		list.add(buildRateType("909915","ORD","CCN","PHP","14.711000"));
		list.add(buildRateType("909915","RTN","CCN","PHP","13.769000"));
		list.add(buildRateType("909915","ORD","CCN","SEK","80.240600"));
		list.add(buildRateType("909915","RTN","CCN","SEK","77.663500"));
		list.add(buildRateType("909915","ORD","CCN","SGD","481.395800"));
		list.add(buildRateType("909915","RTN","CCN","SGD","467.973000"));
		list.add(buildRateType("909915","ORD","CCN","THB","18.868600"));
		list.add(buildRateType("909915","RTN","CCN","THB","18.086600"));
		list.add(buildRateType("909915","ORD","CCN","TWD","21.028200"));
		list.add(buildRateType("909915","RTN","CCN","TWD","19.483800"));
		list.add(buildRateType("909915","ORD","CCN","USD","660.103000"));
		list.add(buildRateType("909915","RTN","CCN","USD","651.740000"));
		list.add(buildRateType("909915","ORD","CCN","VND","0.031500"));
		list.add(buildRateType("909915","RTN","CCN","VND","0.027800"));
		list.add(buildRateType("909918","ORD","CCN","AED","184.327500"));
		list.add(buildRateType("909918","RTN","CCN","AED","174.610400"));
		list.add(buildRateType("909918","ORD","CCN","AUD","477.547900"));
		list.add(buildRateType("909918","RTN","CCN","AUD","464.830300"));
		list.add(buildRateType("909918","ORD","CCN","CAD","508.948800"));
		list.add(buildRateType("909918","RTN","CCN","CAD","495.034800"));
		list.add(buildRateType("909918","ORD","CCN","CHF","668.509800"));
		list.add(buildRateType("909918","RTN","CCN","CHF","649.581300"));
		list.add(buildRateType("909918","ORD","CCN","DKK","100.042300"));
		list.add(buildRateType("909918","RTN","CCN","DKK","96.726200"));
		list.add(buildRateType("909918","ORD","CCN","EUR","738.924900"));
		list.add(buildRateType("909918","RTN","CCN","EUR","719.182500"));
		list.add(buildRateType("909918","ORD","CCN","GBP","968.862600"));
		list.add(buildRateType("909918","RTN","CCN","GBP","943.531500"));
		list.add(buildRateType("909918","ORD","CCN","HKD","84.914500"));
		list.add(buildRateType("909918","RTN","CCN","HKD","83.881200"));
		list.add(buildRateType("909918","ORD","CCN","IDR","0.050400"));
		list.add(buildRateType("909918","RTN","CCN","IDR","0.045500"));
		list.add(buildRateType("909918","ORD","CCN","INR","10.341200"));
		list.add(buildRateType("909918","RTN","CCN","INR","9.076800"));
		list.add(buildRateType("909918","ORD","CCN","JPY","6.013300"));
		list.add(buildRateType("909918","RTN","CCN","JPY","5.853900"));
		list.add(buildRateType("909918","ORD","CCN","KRW","0.576400"));
		list.add(buildRateType("909918","RTN","CCN","KRW","0.537500"));
		list.add(buildRateType("909918","ORD","CCN","MOP","83.040900"));
		list.add(buildRateType("909918","RTN","CCN","MOP","80.905600"));
		list.add(buildRateType("909918","ORD","CCN","MYR","165.049600"));
		list.add(buildRateType("909918","RTN","CCN","MYR","157.885900"));
		list.add(buildRateType("909918","ORD","CCN","NOK","80.301400"));
		list.add(buildRateType("909918","RTN","CCN","NOK","77.720500"));
		list.add(buildRateType("909918","ORD","CCN","NZD","447.673200"));
		list.add(buildRateType("909918","RTN","CCN","NZD","434.082700"));
		list.add(buildRateType("909918","ORD","CCN","PHP","14.711000"));
		list.add(buildRateType("909918","RTN","CCN","PHP","13.769000"));
		list.add(buildRateType("909918","ORD","CCN","SEK","80.240600"));
		list.add(buildRateType("909918","RTN","CCN","SEK","77.663500"));
		list.add(buildRateType("909918","ORD","CCN","SGD","481.395800"));
		list.add(buildRateType("909918","RTN","CCN","SGD","467.973000"));
		list.add(buildRateType("909918","ORD","CCN","THB","18.868600"));
		list.add(buildRateType("909918","RTN","CCN","THB","18.086600"));
		list.add(buildRateType("909918","ORD","CCN","TWD","21.028200"));
		list.add(buildRateType("909918","RTN","CCN","TWD","19.483800"));
		list.add(buildRateType("909918","ORD","CCN","USD","660.103000"));
		list.add(buildRateType("909918","RTN","CCN","USD","651.740000"));
		list.add(buildRateType("909918","ORD","CCN","VND","0.031500"));
		list.add(buildRateType("909918","RTN","CCN","VND","0.027800"));
		list.add(buildRateType("909921","ORD","CCN","AED","184.327500"));
		list.add(buildRateType("909921","RTN","CCN","AED","174.610400"));
		list.add(buildRateType("909921","ORD","CCN","AUD","477.547900"));
		list.add(buildRateType("909921","RTN","CCN","AUD","464.830300"));
		list.add(buildRateType("909921","ORD","CCN","CAD","508.948800"));
		list.add(buildRateType("909921","RTN","CCN","CAD","495.034800"));
		list.add(buildRateType("909921","ORD","CCN","CHF","668.509800"));
		list.add(buildRateType("909921","RTN","CCN","CHF","649.581300"));
		list.add(buildRateType("909921","ORD","CCN","DKK","100.042300"));
		list.add(buildRateType("909921","RTN","CCN","DKK","96.726200"));
		list.add(buildRateType("909921","ORD","CCN","EUR","738.924900"));
		list.add(buildRateType("909921","RTN","CCN","EUR","719.182500"));
		list.add(buildRateType("909921","ORD","CCN","GBP","968.862600"));
		list.add(buildRateType("909921","RTN","CCN","GBP","943.531500"));
		list.add(buildRateType("909921","ORD","CCN","HKD","84.914500"));
		list.add(buildRateType("909921","RTN","CCN","HKD","83.881200"));
		list.add(buildRateType("909921","ORD","CCN","IDR","0.050400"));
		list.add(buildRateType("909921","RTN","CCN","IDR","0.045500"));
		list.add(buildRateType("909921","ORD","CCN","INR","10.341200"));
		list.add(buildRateType("909921","RTN","CCN","INR","9.076800"));
		list.add(buildRateType("909921","ORD","CCN","JPY","6.013300"));
		list.add(buildRateType("909921","RTN","CCN","JPY","5.853900"));
		list.add(buildRateType("909921","ORD","CCN","KRW","0.576400"));
		list.add(buildRateType("909921","RTN","CCN","KRW","0.537500"));
		list.add(buildRateType("909921","ORD","CCN","MOP","83.040900"));
		list.add(buildRateType("909921","RTN","CCN","MOP","80.905600"));
		list.add(buildRateType("909921","ORD","CCN","MYR","165.049600"));
		list.add(buildRateType("909921","RTN","CCN","MYR","157.885900"));
		list.add(buildRateType("909921","ORD","CCN","NOK","80.301400"));
		list.add(buildRateType("909921","RTN","CCN","NOK","77.720500"));
		list.add(buildRateType("909921","ORD","CCN","NZD","447.673200"));
		list.add(buildRateType("909921","RTN","CCN","NZD","434.082700"));
		list.add(buildRateType("909921","ORD","CCN","PHP","14.711000"));
		list.add(buildRateType("909921","RTN","CCN","PHP","13.769000"));
		list.add(buildRateType("909921","ORD","CCN","SEK","80.240600"));
		list.add(buildRateType("909921","RTN","CCN","SEK","77.663500"));
		list.add(buildRateType("909921","ORD","CCN","SGD","481.395800"));
		list.add(buildRateType("909921","RTN","CCN","SGD","467.973000"));
		list.add(buildRateType("909921","ORD","CCN","THB","18.868600"));
		list.add(buildRateType("909921","RTN","CCN","THB","18.086600"));
		list.add(buildRateType("909921","ORD","CCN","TWD","21.028200"));
		list.add(buildRateType("909921","RTN","CCN","TWD","19.483800"));
		list.add(buildRateType("909921","ORD","CCN","USD","660.103000"));
		list.add(buildRateType("909921","RTN","CCN","USD","651.740000"));
		list.add(buildRateType("909921","ORD","CCN","VND","0.031500"));
		list.add(buildRateType("909921","RTN","CCN","VND","0.027800"));
		list.add(buildRateType("909923","ORD","CCN","AED","184.327500"));
		list.add(buildRateType("909923","RTN","CCN","AED","174.610400"));
		list.add(buildRateType("909923","ORD","CCN","AUD","477.547900"));
		list.add(buildRateType("909923","RTN","CCN","AUD","464.830300"));
		list.add(buildRateType("909923","ORD","CCN","CAD","508.948800"));
		list.add(buildRateType("909923","RTN","CCN","CAD","495.034800"));
		list.add(buildRateType("909923","ORD","CCN","CHF","668.509800"));
		list.add(buildRateType("909923","RTN","CCN","CHF","649.581300"));
		list.add(buildRateType("909923","ORD","CCN","DKK","100.042300"));
		list.add(buildRateType("909923","RTN","CCN","DKK","96.726200"));
		list.add(buildRateType("909923","ORD","CCN","EUR","738.924900"));
		list.add(buildRateType("909923","RTN","CCN","EUR","719.182500"));
		list.add(buildRateType("909923","ORD","CCN","GBP","968.862600"));
		list.add(buildRateType("909923","RTN","CCN","GBP","943.531500"));
		list.add(buildRateType("909923","ORD","CCN","HKD","84.914500"));
		list.add(buildRateType("909923","RTN","CCN","HKD","83.881200"));
		list.add(buildRateType("909923","ORD","CCN","IDR","0.050400"));
		list.add(buildRateType("909923","RTN","CCN","IDR","0.045500"));
		list.add(buildRateType("909923","ORD","CCN","INR","10.341200"));
		list.add(buildRateType("909923","RTN","CCN","INR","9.076800"));
		list.add(buildRateType("909923","ORD","CCN","JPY","6.013300"));
		list.add(buildRateType("909923","RTN","CCN","JPY","5.853900"));
		list.add(buildRateType("909923","ORD","CCN","KRW","0.576400"));
		list.add(buildRateType("909923","RTN","CCN","KRW","0.537500"));
		list.add(buildRateType("909923","ORD","CCN","MOP","83.040900"));
		list.add(buildRateType("909923","RTN","CCN","MOP","80.905600"));
		list.add(buildRateType("909923","ORD","CCN","MYR","165.049600"));
		list.add(buildRateType("909923","RTN","CCN","MYR","157.885900"));
		list.add(buildRateType("909923","ORD","CCN","NOK","80.301400"));
		list.add(buildRateType("909923","RTN","CCN","NOK","77.720500"));
		list.add(buildRateType("909923","ORD","CCN","NZD","447.673200"));
		list.add(buildRateType("909923","RTN","CCN","NZD","434.082700"));
		list.add(buildRateType("909923","ORD","CCN","PHP","14.711000"));
		list.add(buildRateType("909923","RTN","CCN","PHP","13.769000"));
		list.add(buildRateType("909923","ORD","CCN","SEK","80.240600"));
		list.add(buildRateType("909923","RTN","CCN","SEK","77.663500"));
		list.add(buildRateType("909923","ORD","CCN","SGD","481.395800"));
		list.add(buildRateType("909923","RTN","CCN","SGD","467.973000"));
		list.add(buildRateType("909923","ORD","CCN","THB","18.868600"));
		list.add(buildRateType("909923","RTN","CCN","THB","18.086600"));
		list.add(buildRateType("909923","ORD","CCN","TWD","21.028200"));
		list.add(buildRateType("909923","RTN","CCN","TWD","19.483800"));
		list.add(buildRateType("909923","ORD","CCN","USD","660.103000"));
		list.add(buildRateType("909923","RTN","CCN","USD","651.740000"));
		list.add(buildRateType("909923","ORD","CCN","VND","0.031500"));
		list.add(buildRateType("909923","RTN","CCN","VND","0.027800"));
		
		return list;
	}
	
	protected RateType buildRateType(String entityCode, String transactionType,String productCode, String currencyCode, String rate){
		RateType r = new RateType();
		
		r.setEntityCode(entityCode);
		r.setTransactionType(transactionType);
		r.setProductCode(productCode);
		r.setCurrencyCode(currencyCode);
		r.setRate(new BigDecimal(rate));
		r.setRateUnits(1);
		
		return r;
	}
	
}
