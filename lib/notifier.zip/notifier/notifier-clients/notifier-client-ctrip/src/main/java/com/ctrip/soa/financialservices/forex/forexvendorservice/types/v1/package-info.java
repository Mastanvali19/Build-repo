@XmlSchema(  namespace = "http://soa.ctrip.com/financialservices/Forex/ForexVendorService/types/v1"
			,elementFormDefault = XmlNsForm.QUALIFIED
//			,attributeFormDefault = XmlNsForm.QUALIFIED
			,xmlns={
				@XmlNs( prefix=""
						,namespaceURI="http://soa.ctrip.com/financialservices/Forex/ForexVendorService/v1")
				,@XmlNs( prefix="types"
			   	   		,namespaceURI="http://soa.ctrip.com/financialservices/Forex/ForexVendorService/types/v1")
			}
)
package com.ctrip.soa.financialservices.forex.forexvendorservice.types.v1;
import javax.xml.bind.annotation.*;