package com.ctrip.soa.financialservices.forex.forexvendorservice.v1;

import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlElement;
import javax.xml.bind.annotation.XmlRootElement;
import javax.xml.bind.annotation.XmlType;

import com.ctrip.soa.financialservices.forex.forexvendorservice.types.v1.ResponseCommon;
import com.ctrip.soa.financialservices.forex.forexvendorservice.types.v1.ResponseStatusType;


@XmlRootElement(name="VendorCurrencyDataSyncResponse", namespace="http://soa.ctrip.com/financialservices/Forex/ForexVendorService/v1")
@XmlAccessorType(XmlAccessType.FIELD)
@XmlType(name = "VendorCurrencyDataSyncResponse", propOrder = {
    "responseStatus",
    "responseCommon"
})
public class VendorCurrencyDataSyncResponse {

    @XmlElement( name = "ResponseStatus"
    			,namespace="http://soa.ctrip.com/financialservices/Forex/ForexVendorService/types/v1")
    protected ResponseStatusType responseStatus;
    
    @XmlElement( name = "ResponseCommon"
    			,required = true
    			,namespace="http://soa.ctrip.com/financialservices/Forex/ForexVendorService/types/v1")
    protected ResponseCommon responseCommon;

    /**
     * Gets the value of the responseStatus property.
     * 
     * @return
     *     possible object is
     *     {@link ResponseStatusType }
     *     
     */
    public ResponseStatusType getResponseStatus() {
        return responseStatus;
    }

    /**
     * Sets the value of the responseStatus property.
     * 
     * @param value
     *     allowed object is
     *     {@link ResponseStatusType }
     *     
     */
    public void setResponseStatus(ResponseStatusType value) {
        this.responseStatus = value;
    }

    /**
     * Gets the value of the responseCommon property.
     * 
     * @return
     *     possible object is
     *     {@link ResponseCommon }
     *     
     */
    public ResponseCommon getResponseCommon() {
        return responseCommon;
    }

    /**
     * Sets the value of the responseCommon property.
     * 
     * @param value
     *     allowed object is
     *     {@link ResponseCommon }
     *     
     */
    public void setResponseCommon(ResponseCommon value) {
        this.responseCommon = value;
    }

}
