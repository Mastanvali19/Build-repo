package com.ctrip.soa.financialservices.forex.forexvendorservice.v1;

import javax.ws.rs.POST;
import javax.ws.rs.Path;

@Path("/apiproxy/soa2/11517/xml/")
public interface ForexVendorServiceInterface {

    @POST
    @Path("/OrderStatusSync/")
    public OrderStatusSyncResponse orderStatusSync(OrderStatusSyncRequest parameters);

    @POST
    @Path("/VendorCurrencyDataSync/")    
    public VendorCurrencyDataSyncResponse vendorCurrencyDataSync(VendorCurrencyDataSyncRequest parameters);

}
