package com.travelex.notifier.client.ctrip.dao;


public interface CtripDao {

	public String getUniqueTransId();
}
