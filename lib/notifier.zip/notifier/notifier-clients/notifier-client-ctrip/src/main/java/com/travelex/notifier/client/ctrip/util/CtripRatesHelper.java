package com.travelex.notifier.client.ctrip.util;

import java.math.BigDecimal;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.Properties;

import org.apache.log4j.Logger;

import com.ctrip.soa.financialservices.forex.forexvendorservice.types.v1.CurrencySyncInfoType;
import com.ctrip.soa.financialservices.forex.forexvendorservice.v1.VendorCurrencyDataSyncRequest;
import com.travelex.notifier.client.conf.RateType;

public class CtripRatesHelper {

	private static final Logger logger = Logger.getLogger(CtripRatesHelper.class);
	private static final String TRANS_ORD = "ORD";
	private static final String TRANS_RTN = "RTN";
	private static final String CONSTANT_RATE = "999999.99";

	public VendorCurrencyDataSyncRequest prepareRates(List<RateType> ratesList, Properties ctripSecurity){
		VendorCurrencyDataSyncRequest request = new VendorCurrencyDataSyncRequest();
		String vendorCode = ctripSecurity.getProperty("vendorCode");
		
		//Map<EntityCode,CurrencyCode,CurrencySyncInfoType>
		Map<String,Map<String,CurrencySyncInfoType>> mapEntities = new HashMap<String,Map<String,CurrencySyncInfoType>>();
		for(RateType rateType : ratesList){
			if(mapEntities.containsKey(rateType.getEntityCode())){
				Map<String,CurrencySyncInfoType> currencyMap = mapEntities.get(rateType.getEntityCode());
				if(currencyMap.containsKey(rateType.getCurrencyCode())){
					CurrencySyncInfoType currencyType = currencyMap.get(rateType.getCurrencyCode());
					setRateValue(currencyType,rateType.getTransactionType(),rateType.getRate());
					currencyMap.put(currencyType.getCurrencyCode(), currencyType);
				}else{
					CurrencySyncInfoType currencyType = buildCurrencySyncInfoType(rateType,vendorCode);
					currencyMap.put(currencyType.getCurrencyCode(), currencyType);
				}
			}else{
				Map<String,CurrencySyncInfoType> currencyMap = new HashMap<String,CurrencySyncInfoType>();
				CurrencySyncInfoType currencyType = buildCurrencySyncInfoType(rateType,vendorCode);
				currencyMap.put(currencyType.getCurrencyCode(), currencyType);
				mapEntities.put(rateType.getEntityCode(), currencyMap);
			}
		}

		//Get the first Entity
		Map<String,CurrencySyncInfoType> currencyMap = mapEntities.get(mapEntities.keySet().toArray()[0]);
		
		for(CurrencySyncInfoType currencyType : currencyMap.values()){
			//Fix non existent rates
			if(currencyType.getBuyRate()== null){
				currencyType.setBuyRate(new BigDecimal(CONSTANT_RATE));
			}
			if(currencyType.getSellRate() == null){
				currencyType.setSellRate(new BigDecimal(CONSTANT_RATE));
			}
			//Re-Set the Entity Code
			currencyType.setBranchCode("ALL");
			
			request.getList().add(currencyType);
		}
		
		return request;
	}
	
	protected CurrencySyncInfoType buildCurrencySyncInfoType(RateType rateType, String vendorCode){
		CurrencySyncInfoType currencyType = new CurrencySyncInfoType();
		currencyType.setBranchCode(rateType.getEntityCode());
		currencyType.setCurrencyCode(rateType.getCurrencyCode());
		currencyType.setVendorCode(vendorCode);
		setRateValue(currencyType,rateType.getTransactionType(),rateType.getRate());
		return currencyType;
	}
	
	protected void setRateValue(CurrencySyncInfoType currencyType, String transactionType, BigDecimal rate){
		if(transactionType.equalsIgnoreCase(TRANS_ORD)){
			currencyType.setSellRate(rate);
		}else if(transactionType.equalsIgnoreCase(TRANS_RTN)){
			currencyType.setBuyRate(rate);
		}
	}
	
}
