package com.ctrip.soa.financialservices.forex.forexvendorservice.v1;

import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlElement;
import javax.xml.bind.annotation.XmlType;

@XmlAccessorType(XmlAccessType.FIELD)
@XmlType(name = "BranchInfo", propOrder = {
    "branchCode",
    "status"
})
public class BranchInfo {

    @XmlElement(required = true)
    protected String branchCode;
    protected short status;

    public String getBranchCode() {
        return branchCode;
    }

    public void setBranchCode(String value) {
        this.branchCode = value;
    }

    public short getStatus() {
        return status;
    }

    public void setStatus(short value) {
        this.status = value;
    }

}
