package com.travelex.notifier.client.ctrip;

import java.io.FileInputStream;
import java.io.IOException;
import java.io.StringWriter;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.HashMap;
import java.util.Map;
import java.util.Properties;

import javax.xml.bind.JAXBContext;
import javax.xml.bind.JAXBException;
import javax.xml.bind.Marshaller;

import org.apache.cxf.interceptor.LoggingInInterceptor;
import org.apache.cxf.interceptor.LoggingOutInterceptor;
import org.apache.cxf.jaxrs.client.ClientConfiguration;
import org.apache.cxf.jaxrs.client.WebClient;
import org.apache.log4j.Logger;
import org.springframework.context.ApplicationContext;
import org.springframework.context.support.ClassPathXmlApplicationContext;

import com.ctrip.soa.financialservices.forex.forexvendorservice.types.v1.RequestCommon;
import com.ctrip.soa.financialservices.forex.forexvendorservice.types.v1.ResponseCommon;
import com.ctrip.soa.financialservices.forex.forexvendorservice.v1.OrderStatusSyncRequest;
import com.ctrip.soa.financialservices.forex.forexvendorservice.v1.OrderStatusSyncResponse;
import com.ctrip.soa.financialservices.forex.forexvendorservice.v1.VendorCurrencyDataSyncRequest;
import com.ctrip.soa.financialservices.forex.forexvendorservice.v1.VendorCurrencyDataSyncResponse;
import com.travelex.notifier.adapter.ConnectorException;
import com.travelex.notifier.adapter.ServiceAdapter;
import com.travelex.notifier.adapter.ServiceAdapterCredentials;
import com.travelex.notifier.client.EventMessageHelper;
import com.travelex.notifier.client.conf.EventMessage;
import com.travelex.notifier.client.conf.OrderUpdateEventMessage;
import com.travelex.notifier.client.conf.RatesUpdateEventMessage;
import com.travelex.notifier.client.ctrip.util.CtripHelper;
import com.travelex.notifier.client.ctrip.util.CtripRatesHelper;

public class CtripAdapterImpl extends ServiceAdapter {

	private static final Logger logger = Logger.getLogger(CtripAdapterImpl.class);
	
	public static final String UPDATE_ORDER = "OrderUpdateEventMessage";
	public static final String UPDATE_RATES = "RatesUpdateEventMessage";

	private static Properties  ctripSecurity;
	private static final String DIR = "/etc/notifier/ctrip";
	
	protected Map<String, String> status;
	protected Map<String, String> statusDescription;
	protected Map<String, String> errorCodes;
	
	protected ApplicationContext context;
	
	public CtripAdapterImpl(ServiceAdapterCredentials credentials,ApplicationContext context) {
		super(credentials);

		if(context == null){
			context = new ClassPathXmlApplicationContext("classpath:applicationContext.xml");
		}
		this.context = context;
		
		getProperties();
		
		initializeMapObjects();
		
	}
	
	@Override
	public boolean invoke(String xml) throws ConnectorException {
		logger.info("invoke xml:[" + xml + "]");

		EventMessageHelper eventMessageHelper = new EventMessageHelper();
		EventMessage message = eventMessageHelper.parseMessage(xml);
		
		if(message!= null && message.getOrderUpdateEventMessage() != null){
			return invokeOrderUpdateService(message.getOrderUpdateEventMessage());
		}else if(message!= null && message.getRatesUpdateEventMessage() != null){
			return invokeRatesUpdateService(message.getRatesUpdateEventMessage()); 
		}else{
			logger.error("Error invoking CTRIP notifier: Invalid request.");
			throw new IllegalArgumentException("Error invoking CTRIP notifier: Invalid request.");
		}
	}

	public boolean invokeOrderUpdateService(OrderUpdateEventMessage orderMessage) {

		if(!status.containsKey(orderMessage.getStatus())){
			logger.info("CTRIP notification is not required for this Foxweb status and is not mapped in notifier app. Order No :  "+ orderMessage.getOrderNo() +" and status : "+ orderMessage.getStatus());
			return true;
		}
		
		OrderStatusSyncRequest orderstatusRequest = buildOrderStatusRequest(orderMessage);
		logger.info("CTRIP OrderStatusSync request payload: [ " + logXMLPayload(OrderStatusSyncRequest.class,orderstatusRequest) + "]");

		try{
			WebClient vendorService = createServiceClient("OrderStatusSync");
			OrderStatusSyncResponse orderStatusResponse = vendorService.post(orderstatusRequest,OrderStatusSyncResponse.class);
			logger.info("CTRIP OrderStatusSync response payload: [ " + logXMLPayload(OrderStatusSyncResponse.class, orderStatusResponse) + "]");
			if (orderStatusResponse != null && orderStatusResponse.getResponseCommon() != null) {
				return handleResponseCodes("OrderStatusSyncResponse",orderStatusResponse.getResponseCommon());
			}else{
				logger.error("CTRIP OrderStatusSync response was empty for order No:" + orderMessage.getOrderNo());
				return false;
			}
		}catch(Exception e){
			logger.error("Error invoking CTRIP - ORDER UPDATE notifier: ",e);
			return false;
		}
		
	}

	public boolean invokeRatesUpdateService(RatesUpdateEventMessage ratesMessage) {
		
		VendorCurrencyDataSyncRequest vendorCurrencyRequest = buildRatesUpdateRequest(ratesMessage);
		
		logger.info("CTRIP VendorCurrencySync request payload: [ " + logXMLPayload(VendorCurrencyDataSyncRequest.class,vendorCurrencyRequest) + "]");
		try{
			if(vendorCurrencyRequest!= null && vendorCurrencyRequest.getList().size() > 0 && vendorCurrencyRequest.getRequestCommon()!= null){
				WebClient vendorService = createServiceClient("VendorCurrencyDataSync");
				VendorCurrencyDataSyncResponse vendorCurrencyResponse = vendorService.post(vendorCurrencyRequest,VendorCurrencyDataSyncResponse.class);
		
				if (vendorCurrencyResponse != null && vendorCurrencyResponse.getResponseCommon() != null) {
					return handleResponseCodes("VendorCurrencyDataSyncResponse",vendorCurrencyResponse.getResponseCommon());
				}
			}
			return false;
			
		}catch(Exception e){
			logger.error("Error invoking CTRIP - RATES UPDATE notifier: ",e);
			return false;
		}

	}

	private String logXMLPayload(Class<?> tClass, Object object){
		StringWriter writer = new StringWriter();
		JAXBContext context;
		try {
			context = JAXBContext.newInstance(tClass);
			Marshaller m = context.createMarshaller();
			m.setProperty(Marshaller.JAXB_FORMATTED_OUTPUT, true);
			m.marshal(object, writer);
			return writer.toString();
		} catch (JAXBException e) {
			logger.error("Error marshalling payload for logging.",e);
			return "";
		}      
	}
	
	
	protected WebClient createServiceClient(String operation) {
		WebClient client = WebClient.create(credentials.getTargetEndpoint()+"/"+operation, credentials.getUsername(), credentials.getPassword(), null);
		ClientConfiguration config = WebClient.getConfig(client);
		config.getHttpConduit().getClient().setAllowChunking(false);
		
	    LoggingInInterceptor inLogger = new LoggingInInterceptor();
	    inLogger.setPrettyLogging(true);
		config.getInInterceptors().add(inLogger);

		LoggingOutInterceptor outLogger = new LoggingOutInterceptor();
		outLogger.setPrettyLogging(true);
		config.getOutInterceptors().add(outLogger);

		return client;
	}
	

	
	protected OrderStatusSyncRequest buildOrderStatusRequest(OrderUpdateEventMessage orderMessage) {
		OrderStatusSyncRequest orderstatusRequest = new OrderStatusSyncRequest();

		RequestCommon requestCommonType = buildCommonRequest();

		orderstatusRequest.setRequestCommon(requestCommonType);
		if(isValid(orderMessage.getExternalOrderNo()) && isValid(orderMessage.getOrderNo()) && isValid(orderMessage.getStatus())){
			orderstatusRequest.setCtripOrderId(orderMessage.getExternalOrderNo());
			orderstatusRequest.setOrderStatus(Short.parseShort(status.get(orderMessage.getStatus())));
			orderstatusRequest.setVendorReferId(orderMessage.getOrderNo());
		}else{
			logger.error("Error invoking CTRIP - ORDER UPDATE notifier: Invalid or empty values in Order update request. Please check the request XML from Foxweb.");
			throw new IllegalArgumentException("Error invoking CTRIP - ORDER UPDATE notifier: Invalid or empty values in Order update request. Please check the request XML from Foxweb.");
		}

		return orderstatusRequest;
	}
	
	protected VendorCurrencyDataSyncRequest buildRatesUpdateRequest(RatesUpdateEventMessage ratesMessage) {
		CtripRatesHelper helper = new CtripRatesHelper();
		
		VendorCurrencyDataSyncRequest vendorCurrencyRequest = new VendorCurrencyDataSyncRequest();
		if(ratesMessage.getRate().size() > 0){
			vendorCurrencyRequest = helper.prepareRates(ratesMessage.getRate(),ctripSecurity);
			vendorCurrencyRequest.setRequestCommon(buildCommonRequest());
		}else{
			logger.error("Error invoking CTRIP - RATES UPDATE notifier: No rates found. Please check the request XML from Foxweb.");
			throw new IllegalArgumentException("Error invoking CTRIP - RATES UPDATE notifier: No rates found. Please check the request XML from Foxweb.");
		}
		
		return vendorCurrencyRequest;
	}

	protected RequestCommon buildCommonRequest() {
		RequestCommon requestCommonType = new RequestCommon();

		Date date = new Date();
		SimpleDateFormat sdf = new SimpleDateFormat("yyyyMMddhhmmss");
		requestCommonType.setReqTime(sdf.format(date));

		CtripHelper helper = new CtripHelper();
		String uniqueTenDigitID = helper.getUniqueTransID(context);
		String vendorCode = ctripSecurity.getProperty("vendorCode");
		String vendorPassword = ctripSecurity.getProperty("vendorPassword");
		
		if(!(isValid(vendorCode) && isValid(vendorPassword))){
			logger.error("Error invoking CTRIP notifier: Invalid security parameters in CTRIP configuration [ vendorCode: "+ vendorCode + " vendorPassword: "+vendorPassword + " ]");
			throw new IllegalArgumentException("Error invoking CTRIP notifier: Invalid security parameters in CTRIP configuration.");
		}
		
		requestCommonType.setVendorCode(vendorCode);
		requestCommonType.setVendorPassword(vendorPassword);
		
		if(isValid(uniqueTenDigitID)){
			StringBuffer transId = new StringBuffer();
			SimpleDateFormat sdFormat = new SimpleDateFormat("yyyyMMdd");
			transId.append(vendorCode).append(sdFormat.format(date)).append(uniqueTenDigitID);
			requestCommonType.setTransID(transId.toString());
		}else{
			logger.error("Error invoking CTRIP - ORDER UPDATE notifier: Unable to create unique transaction ID: " +uniqueTenDigitID);
			throw new IllegalArgumentException("Error invoking CTRIP - ORDER UPDATE notifier: Unable to create unique transaction ID: " +uniqueTenDigitID);
		}
		
		return requestCommonType;
	}

	protected boolean handleResponseCodes(String responseType, ResponseCommon resCom) {

		boolean success = resCom.getResCode().equalsIgnoreCase("000000");
		
		if (success) {
			logger.info("Successful response from CTRIP for Transaction ID: "+ resCom.getTransID());
		} else {
			logger.error("Error from CTRIP service: " +responseType + " [ Transaction ID: "+resCom.getTransID() + " , Response Code: " + resCom.getResCode()
					+ " , Response Description: " + resCom.getResDes() + " , Response Time: " + resCom.getRspTime() + " ]");
		}
		return success;
	}

	@Override
	public Object[] getObjectsEmail(String xml) {

		logger.debug("getObjectsEmail [" + xml + "]");

		EventMessageHelper helper = new EventMessageHelper();
		EventMessage message = helper.parseMessage(xml);

		Object[] obj = new Object[1];

		if(message!= null && (message.getOrderUpdateEventMessage() != null) ){
			OrderUpdateEventMessage orderMessage = message.getOrderUpdateEventMessage();
			obj[0] = buildOrderUpdateEmail(orderMessage,xml);
		}else{
			RatesUpdateEventMessage ratesMessage = message.getRatesUpdateEventMessage();
			obj[0] = buildRateUpdateEmail(ratesMessage,xml);
		}

		return obj;
	}

	private void initializeMapObjects() {
		status = new HashMap<String, String>();
		status.put("Q", "1");
		status.put("V", "2");
		status.put("P", "2");
		status.put("B", "3");
		status.put("K", "4");
		status.put("W", "6");
		//status.put("N", "6");	
		//status.put("X", "6");
		
		statusDescription = new HashMap<String,String>();
		statusDescription.put("Q", "Quote");
		statusDescription.put("V", "Verified");
		statusDescription.put("P", "Processed");
		statusDescription.put("B", "Received");
		statusDescription.put("K", "Picked Up");
		statusDescription.put("W", "Repurchased");
		statusDescription.put("N", "Returned");
		//statusDescription.put("X", "Cancelled");
		
		errorCodes = new HashMap<String,String>();

		errorCodes.put("E00001","Wrong supplier code");
		errorCodes.put("E00002","Supplier verification failed");
		errorCodes.put("E00003","Repeated transaction number");
		errorCodes.put("E00004", "Massage signature vilification failed");
		errorCodes.put("B00001", "Ctrip transaction number does not exsit");
		errorCodes.put("B00002", "Order status code incorrect");
		errorCodes.put("B00003", "Currency code incorrect");
		errorCodes.put("B00004", "Branch code does not exist");
		errorCodes.put("B00005", "Brach stores incorrect");
		
	}
	
	private Object buildOrderUpdateEmail(OrderUpdateEventMessage message, String xml) {
		if(message == null){
			return "";
		}
		xml = xml.replaceAll("<", "&lt;").replaceAll(">", "&gt;");
		StringBuilder emailMessage = new StringBuilder();
		emailMessage.append("<p>OrderStatusSync service failed. Please check the logs for more information.</p>");
		emailMessage.append("<table>");
		emailMessage.append("<tr><td>Order Number: </td><td>"+ message.getOrderNo() + "</td></tr>");
		emailMessage.append("<tr><td>External Order Number: </td><td>"+ message.getExternalOrderNo() + "</td></tr>");
		emailMessage.append("<tr><td>Status: </td><td>"+ statusDescription.get(message.getStatus()) + "</td></tr>");
		emailMessage.append("<tr><td>ID: CTRIP_ORDERUPDATE </td></td>");
		emailMessage.append("<tr><td>Request XML: </td><td><pre lang='xml'>[ "+ xml+ "]</pre></td></tr>");
		emailMessage.append("</table>");
		return emailMessage.toString();
	}
	
	private Object buildRateUpdateEmail(RatesUpdateEventMessage message, String xml) {
		if(message == null){
			return "";
		}
		xml = xml.replaceAll("<", "&lt;").replaceAll(">", "&gt;");
		StringBuilder emailMessage = new StringBuilder();
		emailMessage.append("<p>VendorCurrencyDataSync service failed. Please check the logs for more information.</p>");
		emailMessage.append("<table>");
		emailMessage.append("<tr><td>ID: CTRIP_RATESUPDATE </td></td>");
		emailMessage.append("<tr><td>Request XML: </td><td><pre lang='xml'>[ "+ xml+ "]</pre></td></tr>");
		emailMessage.append("</table>");
		return emailMessage.toString();
	}	
	
	private boolean isValid(String parameter) {
		return (parameter != null && !parameter.equals(""));
	}
	
	public void getProperties(){
		ctripSecurity = new Properties();
		try {
			ctripSecurity.load(new FileInputStream(DIR+"/ctripSecurity.properties"));
			logger.info("Ctrip Security Configuration has been loaded for notifier");
			logger.info("Ctrip Security Configuration = " + ctripSecurity);
		} catch (IOException e) {
			logger.error("Error invoking CTRIP - ORDER UPDATE notifier: ",e);
		}
	}

}
