package com.travelex.notifier.client.ctrip.orderupdate.util.test;

import java.io.UnsupportedEncodingException;
import java.security.MessageDigest;
import java.security.NoSuchAlgorithmException;

public class TestPasswordHashing {

	public static void main(String[] args) throws UnsupportedEncodingException {
		
		String generatedPassword = null;
		String passwordToHash = "123456";
	    try {
	         MessageDigest md = MessageDigest.getInstance("SHA-512");
	        // md.update(salt.getBytes("UTF-8"));
	         byte[] bytes = md.digest(passwordToHash.getBytes("UTF-8"));
	            StringBuilder sb = new StringBuilder();
	            for(int i=0; i< bytes.length ;i++)
	            {
	            	sb.append(Integer.toString((bytes[i] & 0xff) + 0x100, 16).substring(1));
	            }
	            generatedPassword = sb.toString();
	    	
	        } 
	       catch (NoSuchAlgorithmException e){
	        e.printStackTrace();
	       }
	   
	   // System.out.println(generatedPassword);



	}

}
