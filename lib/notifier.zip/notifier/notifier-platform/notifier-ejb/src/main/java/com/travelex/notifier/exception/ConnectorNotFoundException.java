package com.travelex.notifier.exception;

import javax.ejb.ApplicationException;
import javax.jms.MapMessage;

@ApplicationException(rollback = true)
public class ConnectorNotFoundException extends RuntimeException {

	private static final long serialVersionUID = 6714478413779525519L;
	public String id;
	public String xml;
	public String msgId;
	public int attempt;
	MapMessage messageemail;

	public ConnectorNotFoundException() {
		super();
	}

	public ConnectorNotFoundException(String id, String xml, String msgId,
			int attempt) {
		this.id = id;
		this.xml = xml;
		this.msgId = msgId;
		this.attempt = attempt;
	}

}
