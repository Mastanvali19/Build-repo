package com.travelex.notifier.bean;

import javax.annotation.Resource;
import javax.ejb.ActivationConfigProperty;
import javax.ejb.MessageDriven;
import javax.ejb.MessageDrivenContext;
import javax.jms.MapMessage;
import javax.jms.Message;
import javax.jms.MessageListener;

import org.apache.log4j.Logger;

import com.travelex.notifier.exception.ConnectorNotFoundException;
/*import com.travelex.notifier.notifierqueue.TestClassFoxwebMail;*/
import com.travelex.notifier.facade.NotifierFacade;

@MessageDriven(activationConfig = {
		@ActivationConfigProperty(propertyName = "destinationType", propertyValue = "javax.jms.Queue"),
		@ActivationConfigProperty(propertyName = "destination", propertyValue = "jms/notifierComponentQueue") })
public class EventNotifierBean implements MessageListener {

	static Logger log = Logger.getLogger(EventNotifierBean.class);

	@Resource
	private MessageDrivenContext context;

	@Override
	public void onMessage(Message msg) {
		String id = null;
		String xml = null;
		String msgId = null;
		log.debug("STARTED onMessage:" + System.currentTimeMillis());
		try {
			// get all informations to invoke the notifier
			MapMessage map = (MapMessage) msg;
			id = map.getString("id");
			xml = map.getString("xml");
			msgId = msg.getJMSMessageID();
			log.info("Notifier: Received a message [MessageID:"+ msg.getJMSMessageID() + " [id: " + id + " xml: " + xml+ "]" + " System.currentTimeMillis:"+ System.currentTimeMillis() + "]");
			// call notifier logic			
			NotifierFacade.getInstance().notify(id, xml, msgId);
		} catch (Exception e) {
			log.error("Notifer error processing message with message ID"+msgId);
			/*TestClassFoxwebMail tt = new TestClassFoxwebMail();
			tt.doBrowse();
			tt.doBrowseDLQ()*/;
		    throw new ConnectorNotFoundException();
		}
	}	

}



