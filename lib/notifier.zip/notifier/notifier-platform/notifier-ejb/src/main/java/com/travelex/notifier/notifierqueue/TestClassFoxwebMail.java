package com.travelex.notifier.notifierqueue;

import javax.jms.Message;


import javax.jms.Connection;
import javax.jms.ConnectionFactory;

import javax.jms.Queue;
import javax.jms.QueueBrowser;
import javax.jms.Session;
import javax.naming.Context;
import javax.naming.InitialContext;

import java.util.Enumeration;

import org.apache.log4j.Logger;

public class TestClassFoxwebMail{
	
	private static Logger log = Logger.getLogger(TestClassFoxwebMail.class);
	
		
	public void doBrowse(){
		Context ic = null;
		ConnectionFactory cf = null;
		Connection connection = null;

		try {
			ic = new InitialContext();
			cf = (ConnectionFactory) ic.lookup("java:/jms/RemoteConnectionFactory");
			Queue queue = (Queue) ic.lookup("java:/jms/foxwebMailComponentQueue");
			connection = cf.createConnection();

			Session session = connection.createSession(false,Session.AUTO_ACKNOWLEDGE);
			
			QueueBrowser browser = session.createBrowser(queue);
			
			Enumeration msgs = browser.getEnumeration();
			
			if ( !msgs.hasMoreElements() ) { 
			    System.out.println("No messages in queue");
			} else { 
			    while (msgs.hasMoreElements()) { 
			        Message tempMsg = (Message)msgs.nextElement(); 
			        System.out.println("Message: " + tempMsg); 
			    }
			}			
		
			
		} catch (Exception e) {
			e.printStackTrace();
		} finally	{
			try {
				if (connection != null) {
					connection.close();
				}
				if (ic != null) {
					ic.close();
				}
			} catch (Exception e) {
				e.printStackTrace();
			}
		}
	}
	
	public void doBrowseDLQ() {
		Context ic = null;
		ConnectionFactory cf = null;
		Connection connection = null;

		try {
			ic = new InitialContext();
			cf = (ConnectionFactory) ic.lookup("java:/jms/RemoteConnectionFactory");
			Queue queue = (Queue) ic.lookup("java:/jms/foxwebMailDLQQueue");
			connection = cf.createConnection();

			Session session = connection.createSession(false,
					Session.AUTO_ACKNOWLEDGE);

			QueueBrowser browser = session.createBrowser(queue);

			Enumeration msgs = browser.getEnumeration();

			if (!msgs.hasMoreElements()) {
				System.out.println("No messages in queue");
			} else {
				while (msgs.hasMoreElements()) {
					Message tempMsg = (Message) msgs.nextElement();
					System.out.println("Message: " + tempMsg);
				}
			}

		} catch (Exception e) {
			e.printStackTrace();
		} finally {
			try {
				if (connection != null) {
					connection.close();
				}
				if (ic != null) {
					ic.close();
				}
			} catch (Exception e) {
				e.printStackTrace();
			}
		}
	}

}
