package com.travelex.notifier.bean;

import java.util.concurrent.ConcurrentHashMap;

import javax.ejb.ActivationConfigProperty;
import javax.ejb.MessageDriven;
import javax.jms.MapMessage;
import javax.jms.Message;
import javax.jms.MessageListener;

import org.apache.log4j.Logger;
import com.travelex.notifier.facade.NotifierFacade;


@MessageDriven(activationConfig = {
		@ActivationConfigProperty(propertyName = "destinationType", propertyValue = "javax.jms.Queue"),
		@ActivationConfigProperty(propertyName = "destination", propertyValue = "jms/notifierDLQQueue") })
public class NotifierComponentDLQ implements MessageListener {

	private static Logger log = Logger.getLogger(NotifierComponentDLQ.class);

	protected ConcurrentHashMap<String, Integer> messageAttempt = new ConcurrentHashMap<String, Integer>();

	@Override
	public void onMessage(Message msg) {

		try {
			log.info("Publishing message from Deadletter Queue to FoxwebMailComponentQueue");
			MapMessage map = (MapMessage) msg;
			String id = map.getString("id");
			String xml = map.getString("xml");
			NotifierFacade.getInstance().notifyFromDLQ(id, xml,msg.getJMSMessageID());
			log.info("Message Published" + id + xml + msg.getJMSMessageID());
		} catch (Exception e) {
			log.error("Publishing message failed from NotifierDLQ" + msg);
		}
	}
}

