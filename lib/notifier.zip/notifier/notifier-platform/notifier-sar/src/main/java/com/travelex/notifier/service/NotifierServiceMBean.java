package com.travelex.notifier.service;

public interface NotifierServiceMBean {  
	void refreshNotifierConfiguration();
	void reSend(String id, String xml);
	void refreshErrorNotificationConfiguration();
}