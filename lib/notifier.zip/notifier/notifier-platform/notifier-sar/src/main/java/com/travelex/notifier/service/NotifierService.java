package com.travelex.notifier.service;

import javax.jms.Connection;
import javax.jms.ConnectionFactory;
import javax.jms.DeliveryMode;
import javax.jms.MapMessage;
import javax.jms.MessageProducer;
import javax.jms.Queue;
import javax.jms.Session;
import javax.naming.Context;
import javax.naming.InitialContext;

import org.apache.log4j.Logger;

import com.travelex.memcached.DtoCacheManager;
import com.travelex.notifier.facade.NotifierFacade;


public class NotifierService implements	NotifierServiceMBean { 
	
	static Logger log = Logger.getLogger(NotifierService.class);

	// The lifecycle
	protected void startService() throws Exception {
		log.info("Starting NotifierService - SAR");
	}

	protected void stopService() throws Exception {
		log.info("Stopping NotifierService - SAR");
	}

	//clean the configurations stored at memcached
	public void refreshNotifierConfiguration() {
		DtoCacheManager.remove("Notifier.connectorConfigList");
	}
	
	public void reSend(String id, String xml){
		Context ic = null;
		ConnectionFactory cf = null;
		Connection connection = null;

		try {
			
			ic = new InitialContext(); //getConnectionProperties()
			cf = (ConnectionFactory) ic.lookup("jms/RemoteConnectionFactory"); // /java:
			Queue queue = (Queue) ic.lookup("java:/jms/notifierComponentQueue");
			connection = cf.createConnection();

			Session session = connection.createSession(false,Session.AUTO_ACKNOWLEDGE);
			MessageProducer sender = session.createProducer(queue);
			sender.setDeliveryMode(DeliveryMode.PERSISTENT);
			
			MapMessage msg = session.createMapMessage();
			
		    msg.setString("id", id);
		    msg.setString("xml", xml);
		    
			sender.send(msg);		
			
			connection.start();
		
			
		} catch (Exception e) {
			e.printStackTrace();
		} finally	{
			try {
				if (connection != null) {
					connection.close();
				}
				if (ic != null) {
					ic.close();
				}
			} catch (Exception e) {
				e.printStackTrace();
			}
		}		
		
	}
	
	public void refreshErrorNotificationConfiguration(){
		NotifierFacade.getInstance().reloadErrorNotificationConfig();
	}	
	
}